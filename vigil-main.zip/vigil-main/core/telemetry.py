"""
core/telemetry.py — OpenTelemetry bootstrap for Vigil SOC.

When VIGIL_OTEL_ENABLED is falsy OR the SDK cannot be imported, every
public function returns a no-op object. Telemetry failures never crash
the application.

Environment variables:
    VIGIL_OTEL_ENABLED              Master switch ("true"/"1"/"yes" to enable)
    OTEL_EXPORTER_OTLP_ENDPOINT     Collector address (default http://localhost:4317)
    VIGIL_OTEL_RECORD_LLM_CONTENT   Opt-in to recording LLM prompts/responses (default off)
    VIGIL_OTEL_RECORD_IOC_VALUES    Opt-in to recording raw finding/IOC content (default off)
    ENVIRONMENT                     Deployment environment label (default "development")
    RELEASE_VERSION                 Service version label (default "unknown")
"""

from __future__ import annotations

import json
import logging
from contextvars import ContextVar
from typing import Any, Optional

from core.config import get_settings, vigil_path

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Module state
# ---------------------------------------------------------------------------
_initialized: bool = False
_tracer_provider: Any = None
_meter_provider: Any = None

# Context variable for investigation correlation across async tasks
_investigation_id_var: ContextVar[Optional[str]] = ContextVar(
    "vigil_investigation_id", default=None
)


# ---------------------------------------------------------------------------
# Context helpers
# ---------------------------------------------------------------------------


def set_investigation_id(investigation_id: Optional[str]) -> None:
    """Attach an investigation ID to the current async context."""
    _investigation_id_var.set(investigation_id)


def get_investigation_id() -> Optional[str]:
    """Return the investigation ID bound to the current async context."""
    return _investigation_id_var.get()


# ---------------------------------------------------------------------------
# Configuration helpers
# ---------------------------------------------------------------------------


def _is_otel_enabled() -> bool:
    return get_settings().vigil_otel_enabled


# Opt-in flag helpers live in core.telemetry_config so the sanitizer can
# read them without importing this module (breaks the import cycle).
# Re-exported here for backwards compatibility with existing callers/tests.
from core.telemetry_config import (  # noqa: E402,F401
    _should_record_ioc_values,
    _should_record_llm_content,
)

# ---------------------------------------------------------------------------
# Fallback no-op classes (used when OTEL is disabled or SDK missing)
# ---------------------------------------------------------------------------


class _NoOpSpan:
    """No-op span satisfying the OpenTelemetry Span interface."""

    def set_attribute(self, key: str, value: Any) -> None:
        pass

    def set_status(self, status: Any, description: Optional[str] = None) -> None:
        pass

    def record_exception(
        self,
        exception: BaseException,
        attributes: Any = None,
        timestamp: Any = None,
        escaped: bool = False,
    ) -> None:
        pass

    def add_event(
        self, name: str, attributes: Any = None, timestamp: Any = None
    ) -> None:
        pass

    def end(self, end_time: Any = None) -> None:
        pass

    def is_recording(self) -> bool:
        """OTEL SDK defines is_recording as a callable method, not a property."""
        return False

    def get_span_context(self) -> Any:
        return None

    def __enter__(self) -> "_NoOpSpan":
        return self

    def __exit__(self, exc_type: Any, exc_val: Any, exc_tb: Any) -> bool:
        return False


class _FallbackNoOpTracer:
    """No-op tracer returned when OTEL is disabled or unavailable."""

    def start_span(self, name: str, **kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()

    def start_as_current_span(self, name: str, **kwargs: Any) -> _NoOpSpan:
        return _NoOpSpan()


class _NoOpInstrument:
    """No-op metric instrument (counter, histogram, gauge, etc.)."""

    def add(self, amount: Any, attributes: Any = None) -> None:
        pass

    def record(self, amount: Any, attributes: Any = None) -> None:
        pass


class _FallbackNoOpMeter:
    """No-op meter returned when OTEL is disabled or unavailable."""

    def create_counter(self, name: str, **kwargs: Any) -> _NoOpInstrument:
        return _NoOpInstrument()

    def create_histogram(self, name: str, **kwargs: Any) -> _NoOpInstrument:
        return _NoOpInstrument()

    def create_observable_gauge(self, name: str, **kwargs: Any) -> _NoOpInstrument:
        return _NoOpInstrument()

    def create_up_down_counter(self, name: str, **kwargs: Any) -> _NoOpInstrument:
        return _NoOpInstrument()

    def create_observable_counter(self, name: str, **kwargs: Any) -> _NoOpInstrument:
        return _NoOpInstrument()

    def create_observable_up_down_counter(
        self, name: str, **kwargs: Any
    ) -> _NoOpInstrument:
        return _NoOpInstrument()


# ---------------------------------------------------------------------------
# Internal initialization
# ---------------------------------------------------------------------------


def _do_init(service_name: str) -> None:
    """Actually initialize OTEL providers. Raises on any failure."""
    from opentelemetry import metrics, trace
    from opentelemetry.sdk.metrics import MeterProvider
    from opentelemetry.sdk.resources import Resource
    from opentelemetry.sdk.trace import TracerProvider
    from opentelemetry.sdk.trace.export import BatchSpanProcessor

    global _tracer_provider, _meter_provider

    settings = get_settings()
    endpoint = settings.otel_exporter_otlp_endpoint
    environment = settings.environment
    version = settings.release_version

    resource = Resource.create(
        {
            "service.name": service_name,
            "service.version": version,
            "deployment.environment": environment,
            "vigil.component": service_name,
        }
    )

    # --- TracerProvider ---
    try:
        from opentelemetry.exporter.otlp.proto.grpc.trace_exporter import (
            OTLPSpanExporter,
        )

        span_exporter = OTLPSpanExporter(endpoint=endpoint, insecure=True)
    except Exception:
        from opentelemetry.exporter.otlp.proto.http.trace_exporter import (
            OTLPSpanExporter as OTLPSpanExporterHTTP,
        )

        span_exporter = OTLPSpanExporterHTTP(endpoint=endpoint)

    batch_processor = BatchSpanProcessor(
        span_exporter,
        max_queue_size=2048,
        max_export_batch_size=512,
        schedule_delay_millis=5000,
        export_timeout_millis=30000,
    )

    from core.telemetry_sanitizer import SensitiveAttributeScrubber

    tracer_provider = TracerProvider(resource=resource)
    tracer_provider.add_span_processor(SensitiveAttributeScrubber())
    tracer_provider.add_span_processor(batch_processor)

    # Wire Sentry alongside OTEL when configured (prevents double-tracing)
    sentry_dsn = get_settings().sentry_dsn
    if sentry_dsn:
        try:
            from core.platform.monitoring import SentrySpanProcessor

            tracer_provider.add_span_processor(SentrySpanProcessor())
        except Exception:
            pass  # core.platform.monitoring may not be importable in daemon context

    trace.set_tracer_provider(tracer_provider)
    _tracer_provider = tracer_provider

    # --- MeterProvider ---
    # Two readers, not either/or. The Prometheus reader registers its collector
    # on prometheus_client's default REGISTRY, which is what the backend
    # /metrics route and the daemon's :9090 listener serve. The OTLP reader
    # pushes to the collector so processes with no HTTP port (llm-worker)
    # still appear on the collector's Prometheus exporter.
    from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import (
        OTLPMetricExporter,
    )
    from opentelemetry.exporter.prometheus import PrometheusMetricReader
    from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader

    # OTLP first: constructing PrometheusMetricReader registers on REGISTRY, so
    # anything that can raise happens before that side effect.
    otlp_reader = PeriodicExportingMetricReader(
        OTLPMetricExporter(endpoint=endpoint, insecure=True)
    )
    meter_provider = MeterProvider(
        resource=resource,
        metric_readers=[PrometheusMetricReader(), otlp_reader],
    )
    metrics.set_meter_provider(meter_provider)
    _meter_provider = meter_provider

    logger.info(
        "OpenTelemetry initialized for service '%s' → %s", service_name, endpoint
    )


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def init_telemetry(service_name: str) -> bool:
    """
    Bootstrap tracing and metrics for a process.

    Safe to call multiple times — subsequent calls are no-ops if already
    initialized. Returns True if OTEL was actually enabled and initialized.
    """
    global _initialized

    if not _is_otel_enabled():
        logger.debug("VIGIL_OTEL_ENABLED is not set — telemetry disabled")
        return False

    if _initialized:
        return True

    try:
        _do_init(service_name)
        _initialized = True
        _install_json_logging()
        return True
    except Exception as exc:
        logger.warning("OpenTelemetry initialization failed (non-fatal): %s", exc)
        return False


def get_tracer(name: str) -> Any:
    """Return a tracer. Always safe to call — returns a no-op when disabled."""
    if _initialized:
        try:
            from opentelemetry import trace

            return trace.get_tracer(name)
        except Exception:
            pass
    return _FallbackNoOpTracer()


def get_meter(name: str) -> Any:
    """Return a meter. Always safe to call — returns a no-op when disabled."""
    if _initialized:
        try:
            from opentelemetry import metrics

            return metrics.get_meter(name)
        except Exception:
            pass
    return _FallbackNoOpMeter()


def inject_traceparent(carrier: Optional[dict] = None) -> dict:
    """
    Inject the current W3C traceparent into *carrier* (mutates and returns it).
    Used to propagate trace context across async boundaries (e.g. ARQ jobs).
    """
    if carrier is None:
        carrier = {}
    if _initialized:
        try:
            from opentelemetry.propagators.textmap import TraceContextTextMapPropagator

            TraceContextTextMapPropagator().inject(carrier)
        except Exception:
            pass
    return carrier


def extract_traceparent(carrier: dict) -> Any:
    """
    Extract W3C trace context from *carrier* and return an OTEL Context.
    Returns None when disabled or on any error.
    """
    if _initialized and carrier:
        try:
            from opentelemetry.propagators.textmap import TraceContextTextMapPropagator

            return TraceContextTextMapPropagator().extract(carrier)
        except Exception:
            pass
    return None


def create_genai_metrics(meter: Any) -> dict:
    """
    Create and return the 4 GenAI metric instruments used for LLM observability.

    Keys: llm_calls, llm_duration, llm_tokens, llm_cost_usd
    """
    return {
        "llm_calls": meter.create_counter(
            "vigil.llm.calls.total",
            description="Total LLM API calls",
        ),
        "llm_duration": meter.create_histogram(
            "vigil.llm.duration.seconds",
            description="LLM call duration in seconds",
        ),
        "llm_tokens": meter.create_counter(
            "vigil.llm.tokens.total",
            description="Total LLM tokens consumed",
        ),
        "llm_cost_usd": meter.create_counter(
            "vigil.llm.cost.usd.total",
            description="Cumulative LLM cost in USD",
        ),
    }


# GenAI instruments, created on first record. Only cached once the real
# MeterProvider is installed: get_meter() before init_telemetry() returns
# _FallbackNoOpMeter, and caching that would silence the counters for the
# life of the process.
_genai_metrics: Optional[dict] = None


def record_llm_call(
    *,
    model: Optional[str],
    provider: Optional[str],
    input_tokens: int,
    output_tokens: int,
    cache_read_tokens: int = 0,
    cache_creation_tokens: int = 0,
    duration_s: float,
    cost_usd: Optional[float],
) -> None:
    """
    Record one completed LLM call on the four GenAI instruments.

    Attributes are limited to ``model`` / ``provider`` (plus ``token_type`` on
    the token counter) — never prompt or response content. Runs on the
    request path, so it swallows every exception; it is a no-op when OTEL is
    disabled. An unpriced call (``cost_usd is None``) is still counted, but
    adds nothing to the cost instrument rather than a guessed $0.
    """
    global _genai_metrics
    try:
        # Normalise everything before touching any instrument so a bad value
        # skips the whole record rather than leaving the four out of step.
        tokens = {
            "input": int(input_tokens or 0),
            "output": int(output_tokens or 0),
            "cache_read": int(cache_read_tokens or 0),
            "cache_creation": int(cache_creation_tokens or 0),
        }
        duration = max(float(duration_s or 0.0), 0.0)
        cost = None if cost_usd is None else max(float(cost_usd), 0.0)
        attrs = {"model": model or "unknown", "provider": provider or "unknown"}

        metrics = _genai_metrics
        if metrics is None:
            meter = get_meter("vigil.llm")
            metrics = create_genai_metrics(meter)
            if _initialized and not isinstance(meter, _FallbackNoOpMeter):
                _genai_metrics = metrics

        metrics["llm_calls"].add(1, attrs)
        metrics["llm_duration"].record(duration, attrs)
        if cost is not None:
            metrics["llm_cost_usd"].add(cost, attrs)
        for token_type, count in tokens.items():
            if count:
                metrics["llm_tokens"].add(count, {**attrs, "token_type": token_type})
    except Exception:
        pass


def shutdown() -> None:
    """
    Flush and shut down all telemetry providers.

    Safe to call even when OTEL was never initialized.
    After shutdown, init_telemetry() may be called again.
    """
    global _initialized, _tracer_provider, _meter_provider, _genai_metrics

    if _tracer_provider is not None:
        try:
            _tracer_provider.force_flush(timeout_millis=30000)
            _tracer_provider.shutdown()
        except Exception as exc:
            logger.warning("TracerProvider shutdown error (non-fatal): %s", exc)

    if _meter_provider is not None:
        try:
            _meter_provider.force_flush(timeout_millis=30000)
            _meter_provider.shutdown()
        except Exception as exc:
            logger.warning("MeterProvider shutdown error (non-fatal): %s", exc)

    _tracer_provider = None
    _meter_provider = None
    _genai_metrics = None  # instruments belong to the provider just shut down
    _initialized = False  # reset so init_telemetry() can be called again


# Alias used in the plan and by callers that prefer the longer name
shutdown_telemetry = shutdown


# ---------------------------------------------------------------------------
# Structured JSON logging with OTEL trace correlation (#59)
# ---------------------------------------------------------------------------


def current_trace_ids() -> tuple[str, str]:
    """Hex (trace_id, span_id) of the active OTEL span, or empty strings."""
    try:
        from opentelemetry import trace

        ctx = trace.get_current_span().get_span_context()
        if ctx and ctx.is_valid:
            return format(ctx.trace_id, "032x"), format(ctx.span_id, "016x")
    except Exception:
        pass
    return "", ""


def _install_json_logging() -> None:
    """
    Replace the root logger's handlers with structured JSON output.

    Each log line includes trace_id and span_id from the current OTEL span
    so that logs can be correlated with traces in Jaeger/Grafana.
    Retains file output alongside stdout.
    """

    class _OTELJsonFormatter(logging.Formatter):
        def format(self, record: logging.LogRecord) -> str:
            trace_id, span_id = current_trace_ids()

            entry: dict = {
                "ts": self.formatTime(record, "%Y-%m-%dT%H:%M:%S.%f"),
                "level": record.levelname,
                "logger": record.name,
                "message": record.getMessage(),
                "trace_id": trace_id,
                "span_id": span_id,
            }

            inv_id = get_investigation_id()
            if inv_id:
                entry["vigil.investigation.id"] = inv_id

            if record.exc_info:
                entry["exception"] = self.formatException(record.exc_info)

            for key, val in record.__dict__.items():
                if key.startswith("vigil."):
                    entry[key] = val

            return json.dumps(entry, default=str)

    root = logging.getLogger()
    for handler in root.handlers[:]:
        root.removeHandler(handler)

    formatter = _OTELJsonFormatter()

    console = logging.StreamHandler()
    console.setFormatter(formatter)
    root.addHandler(console)

    try:
        log_dir = vigil_path(write=True)
        file_handler = logging.FileHandler(log_dir / "vigil.log")
        file_handler.setFormatter(formatter)
        root.addHandler(file_handler)
    except Exception as exc:
        logger.warning("Could not set up file logging (non-fatal): %s", exc)
