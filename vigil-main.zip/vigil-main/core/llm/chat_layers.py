# The config layer a chat turn runs under. Assembled per request because which
# tools a conversation may reach depends on the agent the operator picked, and
# the agent registry lives on this side of the boundary.

from __future__ import annotations

import re
import uuid
from collections import Counter
from typing import Any, Dict, List, Optional, Tuple

import yaml

from core.integrations.atomic_red_team.descriptor import EXECUTE_IDS
from core.integrations.mcp.surface import VIGIL_SERVER
from core.llm.tool_schemas import ALL_TOOLS

REMOTE = "remote"

# Direct-action verbs that make an MCP tool destructive: calling it changes the
# world (isolates a host, blocks an IP, kills a process) and a later read cannot
# undo it. Chat offers every connected MCP tool the provider will take, and says
# which it would not (see ``_declare`` and ``trim_servers``), but the chat surface has no approval-resume path — a parked call would hang
# forever, never gate — so these are dropped from chat entirely. Real containment
# goes through the approval queue (``create_approval_action``) and workflows, not
# ad-hoc chat calls.
_DESTRUCTIVE_VERBS = frozenset(
    {
        "isolate",
        "unisolate",
        "contain",
        "quarantine",
        "block",
        "unblock",
        "kill",
        "terminate",
        "shutdown",
        "disable",
        "deactivate",
        "suspend",
        "delete",
        "remove",
        "purge",
        "wipe",
        "revoke",
        "ban",
        "remediate",
        "detonate",
        "reset",
        "release",
    }
)
# A read-only lead verb (get_isolation_status, list_blocked_ips) is safe even
# when a destructive noun follows, so it overrides the verb check.
_READONLY_LEADS = frozenset(
    {
        "get",
        "list",
        "search",
        "describe",
        "fetch",
        "query",
        "show",
        "read",
        "lookup",
        "count",
        "stats",
        "status",
        "check",
    }
)


def _is_destructive_mcp(name: str) -> bool:
    """True for a server-prefixed MCP tool that performs an irreversible action.

    Every token of the id is read, the server prefix included. Vendor tools
    arrive as ``{server}_{tool}`` and Vigil's own arrive bare, so there is no
    one prefix to strip — and stripping the first token off a bare name takes
    the verb, which is the whole of what this decides on: ``isolate_host``
    would be read as ``host``.

    A read-only lead verb wins outright; otherwise any destructive verb token
    marks it. Reading the prefix too can only over-drop, and that is the side to
    err on — a spurious drop means chat recommends the action instead of calling
    it, whereas a missed one is an ungated detonation.

    ART execute is named, not verb-matched: adding ``execute`` to the verb set
    would also drop ``splunk_execute``.
    """
    if name in EXECUTE_IDS:
        return True
    tokens = name.split("_")
    if not tokens:
        return False
    if tokens[0] in _READONLY_LEADS:
        return False
    return any(tok in _DESTRUCTIVE_VERBS for tok in tokens)


# A conversation is one answer at a time with a person waiting, so the ceiling is
# per turn rather than per run: they will say so long before a budget would.
DEFAULT_BUDGETS = {"max_calls": 12, "max_wall_ms": 300_000, "max_cost_usd": 2.0}
DEFAULT_RUNTIME = {"max_turns": 8, "result_cap": 20_000, "recall_limit": 3}

# A session id is the console's and is not a uuid; a run id is. Derived rather
# than generated so every turn of one conversation lands on the same run.
CONVERSATIONS = uuid.UUID("6ba7b812-9dad-11d1-80b4-00c04fd430c8")


def run_id_for(session_id: str) -> str:
    return str(uuid.uuid5(CONVERSATIONS, session_id))


# A tool with no description is dropped rather than declared: the agent layer
# refuses one, because a model cannot choose between two blank tools.
def _declare(
    wanted: Optional[List[str]],
    mcp_tools: Optional[List[Dict[str, Any]]] = None,
) -> List[Dict[str, Any]]:
    # Two surfaces. Static built-ins are curated: a per-agent recommended-tools
    # list (``wanted``) narrows them. Chat offers every connected MCP tool
    # (server-prefixed, e.g. virustotal_get_ip_report) the provider will take,
    # and says which it would not — a user who connected an integration expects
    # the assistant to use it regardless of any agent's tool list, and hunts
    # curate separately (playbook_resolver). So a ``wanted`` list filters only
    # the built-ins; live integrations are appended — except direct-action MCP
    # tools (see ``_is_destructive_mcp``), which chat cannot safely gate. What
    # the provider will not take is cut by ``trim_servers``, never here.
    static = {t["name"]: t for t in ALL_TOOLS if t.get("name")}
    mcp = {t["name"]: t for t in (mcp_tools or []) if t.get("name")}
    static_names = (
        list(static) if wanted is None else [n for n in wanted if n in static]
    )
    # Chat has no approval-resume path. Isolate/contain drop via the verb set;
    # ART execute is an explicit id (native and flattened) so ``execute`` stays
    # off that set and splunk_execute remains callable.
    #
    # ``approve_action`` is not dropped, and that is the decision rather than an
    # oversight: what it approves is an action a person already queued and can
    # already release from the approvals screen, so chat releasing it is the same
    # authority reached by a different door -- whereas ``isolate_host`` in chat
    # would be a detonation nobody queued. If that reading is ever revisited, the
    # thing to change is this list, not the verb set, which decides a different
    # question.
    static_names = [n for n in static_names if n not in EXECUTE_IDS]
    mcp_names = [n for n in mcp if n not in static_names and not _is_destructive_mcp(n)]
    names = static_names + mcp_names
    # Static last, so a name both sides carry is described by the side that will
    # answer it: tools_router tries the backend first and only reaches an MCP
    # server for a name the backend does not claim. Spreading mcp last instead
    # declared the MCP tool's schema against the backend's implementation -- and
    # dropped six tools outright below, because those MCP tools carry no
    # docstring and a tool with no description is not offered at all.
    catalogue = {**mcp, **static}
    declared = []
    for name in names:
        entry = catalogue[name]
        description = (entry.get("description") or "").strip()
        if not description:
            continue
        declared.append(
            {
                "id": name,
                "kind": REMOTE,
                "description": description,
                "parameters": entry.get("input_schema") or {"type": "object"},
            }
        )
    return declared


# The provider names its own ceiling when it refuses the array, and that number
# is the only one used: nothing is configured or stored per model, and a
# provider that has no ceiling, or says it another way, never reaches this.
# The array itself, not ``tools[3].function.name``, whose length limit is not one.
_TOOLS_CEILING = re.compile(
    r"\btools\b(?!\[)[^\n]*?\barray\b[^\n]*?\bmaximum length (\d+)", re.I
)


def tools_ceiling(reason: str) -> Optional[int]:
    """The tools-array maximum a provider rejection states, else None."""
    match = _TOOLS_CEILING.search(reason or "")
    return int(match.group(1)) if match else None


def trim_servers(
    wanted: Optional[List[str]],
    mcp_tools: Optional[List[Dict[str, Any]]],
    servers: Dict[str, str],
    maximum: int,
) -> Optional[Tuple[List[Dict[str, Any]], List[str]]]:
    """Drop whole third-party MCP servers until ``_declare`` fits ``maximum``.

    Returns the MCP tools to declare instead and the servers left out, or None
    when nothing needs dropping or nothing fits. Whole servers, because a
    search whose fetch is missing fails in a way the model cannot reason about;
    largest first (ties by name), so the fewest are lost. The built-in
    catalogue and Vigil's own server are what the agent is, and never go.
    """
    declared = _declare(wanted, mcp_tools)
    static = {t["name"] for t in ALL_TOOLS if t.get("name")}

    def droppable(name: str) -> Optional[str]:
        server = servers.get(name)
        return None if name in static or server == VIGIL_SERVER else server

    sizes = Counter(filter(None, (droppable(t["id"]) for t in declared)))
    excess = len(declared) - maximum
    if excess <= 0:
        return None
    dropped: List[str] = []
    for server, size in sorted(sizes.items(), key=lambda kv: (-kv[1], kv[0])):
        if excess <= 0:
            break
        dropped.append(server)
        excess -= size
    if excess > 0:
        return None
    kept = [t for t in mcp_tools or [] if droppable(t.get("name", "")) not in dropped]
    return kept, dropped


def chat_config(
    model: str,
    tools: Optional[List[str]] = None,
    mcp_tools: Optional[List[Dict[str, Any]]] = None,
    provider: Optional[str] = None,
) -> str:
    """Render the agent layer's config document.

    ``provider`` is the gateway's provider name, carried separately from the
    model rather than folded into it: Bifrost routes ``<provider>/<model>`` but
    the price catalogue is keyed by the bare id, so the agent needs both. Left
    out when unknown, which is what every caller did before this existed.
    """
    document = {
        "model": model,
        **({"provider": provider} if provider else {}),
        "budgets": DEFAULT_BUDGETS,
        "runtime": DEFAULT_RUNTIME,
        "tools": _declare(tools, mcp_tools),
        # A chat tool asks the person directly rather than parking on a
        # checkpoint: they are already in the conversation.
        "approvals": [],
        "thresholds": {},
    }
    return yaml.safe_dump(
        document, default_flow_style=False, sort_keys=False, allow_unicode=True
    )
