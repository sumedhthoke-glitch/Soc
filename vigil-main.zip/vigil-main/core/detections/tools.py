"""
Security-Detections tool integration - Pure Python implementation
Provides access to 7,200+ detection rules across Sigma, Splunk, Elastic, and KQL formats
"""

import os
import re
from collections import defaultdict
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml

from core.agents.projections import read_projection
from core.config import _safe_home
from core.detections.lint import lint_sigma
from core.detections.reconstruction import (
    coverage_report,
    reconstruct,
    span_for_steps,
    steps_from_dispatch_results,
)
from core.storage.database_data_service import DatabaseDataService


class SecurityDetectionsTools:
    """
    Main class for security detection tools integration.
    Loads and indexes detection rules from multiple formats.

    Paths are resolved dynamically from DetectionRulesService when available,
    falling back to environment variables and then default paths.
    """

    def __init__(self):
        """Initialize with detection rule paths from dynamic service or environment."""
        # Try to get paths dynamically from DetectionRulesService
        paths = self._get_dynamic_paths()

        self.sigma_path = Path(
            paths.get(
                "sigma",
                os.getenv(
                    "SIGMA_PATHS", str(_safe_home() / "security-detections/sigma/rules")
                ),
            )
        )
        self.splunk_path = Path(
            paths.get(
                "splunk",
                os.getenv(
                    "SPLUNK_PATHS",
                    str(
                        _safe_home() / "security-detections/security_content/detections"
                    ),
                ),
            )
        )
        self.elastic_path = Path(
            paths.get(
                "elastic",
                os.getenv(
                    "ELASTIC_PATHS",
                    str(_safe_home() / "security-detections/detection-rules/rules"),
                ),
            )
        )
        self.kql_path = Path(
            paths.get(
                "kql",
                os.getenv(
                    "KQL_PATHS",
                    str(
                        _safe_home()
                        / "security-detections/Hunting-Queries-Detection-Rules"
                    ),
                ),
            )
        )

        self.detections = []
        self.detections_by_technique = defaultdict(list)
        self.detections_by_source = defaultdict(list)
        self._loaded = False

    def _get_dynamic_paths(self) -> Dict:
        """Get paths from DetectionRulesService if available."""
        try:
            from core.detections.detection_rules_service import DetectionRulesService

            env_vars = DetectionRulesService().get_mcp_env_vars()

            paths = {}
            if "SIGMA_PATHS" in env_vars:
                # Take only the first path if multiple are comma-separated
                paths["sigma"] = env_vars["SIGMA_PATHS"].split(",")[0]
            if "SPLUNK_PATHS" in env_vars:
                paths["splunk"] = env_vars["SPLUNK_PATHS"].split(",")[0]
            if "ELASTIC_PATHS" in env_vars:
                paths["elastic"] = env_vars["ELASTIC_PATHS"].split(",")[0]
            if "KQL_PATHS" in env_vars:
                paths["kql"] = env_vars["KQL_PATHS"].split(",")[0]

            return paths
        except Exception:
            return {}

    def reload(self):
        """Reload detection rules (clears cache and re-reads from sources)."""
        self._loaded = False
        self.detections = []
        self.detections_by_technique = defaultdict(list)
        self.detections_by_source = defaultdict(list)

        # Refresh paths from dynamic service
        paths = self._get_dynamic_paths()
        if paths.get("sigma"):
            self.sigma_path = Path(paths["sigma"])
        if paths.get("splunk"):
            self.splunk_path = Path(paths["splunk"])
        if paths.get("elastic"):
            self.elastic_path = Path(paths["elastic"])
        if paths.get("kql"):
            self.kql_path = Path(paths["kql"])

        self._load_detections()

    def _load_detections(self):
        """Load all detection files (lazy loading)"""
        if self._loaded:
            return

        print("Loading detection rules...")

        # Load Sigma rules
        if self.sigma_path.exists():
            for file_path in self.sigma_path.rglob("*.yml"):
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        detection = yaml.safe_load(f)
                        if detection and isinstance(detection, dict):
                            detection["_source"] = "sigma"
                            detection["_file_path"] = str(file_path)
                            self.detections.append(detection)
                            self.detections_by_source["sigma"].append(detection)

                            # Index by MITRE technique
                            tags = detection.get("tags", [])
                            for tag in tags:
                                if isinstance(tag, str) and tag.startswith("attack.t"):
                                    technique = tag.replace("attack.", "").upper()
                                    self.detections_by_technique[technique].append(
                                        detection
                                    )
                except Exception:
                    pass  # Skip malformed files

        # Load Splunk ESCU rules
        if self.splunk_path.exists():
            for file_path in self.splunk_path.rglob("*.yml"):
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        detection = yaml.safe_load(f)
                        if detection and isinstance(detection, dict):
                            detection["_source"] = "splunk"
                            detection["_file_path"] = str(file_path)
                            self.detections.append(detection)
                            self.detections_by_source["splunk"].append(detection)

                            # Index by MITRE technique
                            tags = detection.get("tags", {}).get("mitre_attack_id", [])
                            if isinstance(tags, list):
                                for tag in tags:
                                    self.detections_by_technique[tag.upper()].append(
                                        detection
                                    )
                except Exception:
                    pass

        # Load Elastic rules
        if self.elastic_path.exists():
            for file_path in self.elastic_path.rglob("*.toml"):
                try:
                    # Simple TOML parsing for threat section
                    with open(file_path, "r", encoding="utf-8") as f:
                        content = f.read()
                        detection = {
                            "_source": "elastic",
                            "_file_path": str(file_path),
                            "_content": content,
                        }
                        self.detections.append(detection)
                        self.detections_by_source["elastic"].append(detection)

                        # Extract technique IDs from content
                        techniques = re.findall(
                            r'technique_id\s*=\s*"(T\d{4}(?:\.\d{3})?)"', content
                        )
                        for technique in techniques:
                            self.detections_by_technique[technique.upper()].append(
                                detection
                            )
                except Exception:
                    pass

        # Load KQL rules (.yaml and .md files)
        if self.kql_path.exists():
            # Load .yaml KQL rules (if any exist)
            for file_path in self.kql_path.rglob("*.yaml"):
                try:
                    with open(file_path, "r", encoding="utf-8") as f:
                        detection = yaml.safe_load(f)
                        if detection and isinstance(detection, dict):
                            detection["_source"] = "kql"
                            detection["_file_path"] = str(file_path)
                            self.detections.append(detection)
                            self.detections_by_source["kql"].append(detection)

                            # Index by MITRE technique
                            techniques = detection.get("mitre", [])
                            if isinstance(techniques, list):
                                for technique in techniques:
                                    self.detections_by_technique[
                                        technique.upper()
                                    ].append(detection)
                except Exception:
                    pass

            # Load .md KQL rules (Hunting-Queries-Detection-Rules format)
            for file_path in self.kql_path.rglob("*.md"):
                # Skip README files and templates
                if file_path.name.lower() in ("readme.md", "detectiontemplate.md"):
                    continue
                try:
                    detection = self._parse_kql_markdown(file_path)
                    if detection:
                        self.detections.append(detection)
                        self.detections_by_source["kql"].append(detection)

                        # Index by MITRE technique
                        for technique in detection.get("mitre", []):
                            self.detections_by_technique[technique.upper()].append(
                                detection
                            )
                except Exception:
                    pass

        self._loaded = True
        print(f"Loaded {len(self.detections)} detection rules")
        print(f"  Sigma: {len(self.detections_by_source['sigma'])}")
        print(f"  Splunk: {len(self.detections_by_source['splunk'])}")
        print(f"  Elastic: {len(self.detections_by_source['elastic'])}")
        print(f"  KQL: {len(self.detections_by_source['kql'])}")

    async def analyze_coverage(
        self,
        techniques: Optional[List[str]] = None,
        run_id: Optional[str] = None,
        steps: Any = None,
        **_kwargs: object,
    ) -> Dict:
        """Catalog counts for techniques, or a run report when run_id / steps is set.

        Extra kwargs (including ``limit`` injected by ``/internal/tools/invoke``)
        are ignored. A run id or action trace is the report path, not catalog
        counts mixed into the same rows.
        """
        trace_given = isinstance(steps, list)
        if (trace_given and steps) or run_id or (trace_given and not techniques):
            return await self._run_coverage(
                run_id=run_id,
                steps=steps if trace_given else None,
            )
        if techniques is None:
            return {
                "error": "techniques is required unless run_id or steps is provided"
            }

        self._load_detections()

        coverage = {}
        for technique in techniques:
            technique_upper = technique.upper()
            matching = self.detections_by_technique.get(technique_upper, [])

            # Count by source
            by_source = defaultdict(int)
            for detection in matching:
                by_source[detection["_source"]] += 1

            coverage[technique] = {
                "count": len(matching),
                "by_source": dict(by_source),
                "detections": [
                    {
                        "title": d.get("title") or d.get("name", "Untitled"),
                        "source": d["_source"],
                        "id": d.get("id", ""),
                        "description": d.get("description", "")[:200],
                    }
                    for d in matching[:5]  # Top 5
                ],
            }

        return coverage

    async def _run_coverage(self, run_id: Optional[str], steps: Any) -> Dict:
        if isinstance(steps, list) and steps:
            trace: List = steps
        elif run_id:
            projection = await read_projection(run_id)
            if projection is None:
                return {
                    "run_id": run_id,
                    "techniques": [],
                    "error": "no readable run",
                }
            trace = steps_from_dispatch_results(projection.get("results"))
        else:
            trace = steps if isinstance(steps, list) else []
        reconstructed = await self.reconstruct_run(steps=trace)
        report = coverage_report(trace, reconstructed)
        if run_id:
            report["run_id"] = run_id
        return report

    async def search_detections(
        self, query: str, source_type: Optional[str] = None, limit: int = 20
    ) -> List[Dict]:
        """
        Search across all detection rules using keywords.

        Args:
            query: Search query (e.g., "powershell base64", "lateral movement")
            source_type: Optional filter by source ("sigma", "splunk", "elastic", "kql")
            limit: Maximum number of results

        Returns:
            List of matching detection rules
        """
        self._load_detections()

        query_lower = query.lower()
        results = []

        detections_to_search = self.detections
        if source_type:
            detections_to_search = self.detections_by_source.get(source_type, [])

        for detection in detections_to_search:
            # Search in title, description, tags
            searchable = str(detection).lower()
            if query_lower in searchable:
                results.append(
                    {
                        "title": detection.get("title")
                        or detection.get("name", "Untitled"),
                        "source": detection["_source"],
                        "id": detection.get("id", ""),
                        "description": detection.get("description", "")[:300],
                        "file_path": detection["_file_path"],
                    }
                )

                if len(results) >= limit:
                    break

        return results

    async def get_detection_count(self, source_type: Optional[str] = None) -> Dict:
        """
        Get count of detections by source.

        Args:
            source_type: Optional filter by source

        Returns:
            Count information
        """
        self._load_detections()

        if source_type:
            return {
                "source": source_type,
                "count": len(self.detections_by_source.get(source_type, [])),
            }

        return {
            "total": len(self.detections),
            "by_source": {
                source: len(detections)
                for source, detections in self.detections_by_source.items()
            },
        }

    async def identify_gaps(self, context: str) -> Dict:
        """
        Identify detection gaps for a given context (e.g., "ransomware", "APT29").

        Args:
            context: Context for gap analysis

        Returns:
            Gap analysis results
        """
        self._load_detections()

        # Common ransomware techniques
        ransomware_techniques = [
            "T1486",  # Data Encrypted for Impact
            "T1490",  # Inhibit System Recovery
            "T1489",  # Service Stop
            "T1047",  # Windows Management Instrumentation
            "T1059.001",  # PowerShell
        ]

        # For demonstration, analyze common techniques
        # In production, this would map context to specific technique sets
        techniques_to_check = (
            ransomware_techniques if "ransomware" in context.lower() else []
        )

        gaps = []
        coverage_map = {}

        for technique in techniques_to_check:
            matching = self.detections_by_technique.get(technique, [])
            count = len(matching)
            coverage_map[technique] = count

            if count < 3:  # Threshold for "gap"
                gaps.append(
                    {
                        "technique": technique,
                        "current_coverage": count,
                        "priority": "high" if count == 0 else "medium",
                    }
                )

        return {
            "context": context,
            "techniques_analyzed": len(techniques_to_check),
            "gaps_identified": len(gaps),
            "gaps": gaps,
            "coverage_map": coverage_map,
        }

    async def get_coverage_stats(self, source_type: Optional[str] = None) -> Dict:
        """
        Get overall coverage statistics.

        Args:
            source_type: Optional filter by source

        Returns:
            Coverage statistics
        """
        self._load_detections()

        stats = {
            "total_detections": len(self.detections),
            "techniques_covered": len(self.detections_by_technique),
            "by_source": {
                source: {
                    "count": len(detections),
                    "techniques": len(
                        set(
                            tech
                            for det in detections
                            for tech in self._extract_techniques(det)
                        )
                    ),
                }
                for source, detections in self.detections_by_source.items()
            },
        }

        if source_type and source_type in self.detections_by_source:
            return {"source": source_type, **stats["by_source"][source_type]}

        return stats

    def _parse_kql_markdown(self, file_path: Path) -> Optional[Dict]:
        """
        Parse a KQL markdown file from the Hunting-Queries-Detection-Rules repo.

        Expected format:
            # Title
            ## Query Information
            #### MITRE ATT&CK Technique(s)
            | Technique ID | Title | Link |
            | --- | --- | --- |
            | T1210 | Exploitation of Remote Services | ... |
            #### Description
            Description text...
            ## Defender XDR / Sentinel
            ```KQL
            ...query...
            ```
        """
        with open(file_path, "r", encoding="utf-8") as f:
            content = f.read()

        if not content.strip():
            return None

        # Extract title from first markdown heading
        title_match = re.search(r"^#\s+(.+)", content, re.MULTILINE)
        title = title_match.group(1).strip() if title_match else file_path.stem

        # Extract description from #### Description section
        desc_match = re.search(
            r"####\s+Description\s*\n(.*?)(?=\n####|\n##|\n```|\Z)", content, re.DOTALL
        )
        description = desc_match.group(1).strip() if desc_match else ""

        # Extract MITRE technique IDs from the table or anywhere in the doc
        mitre_techniques = list(set(re.findall(r"(T\d{4}(?:\.\d{3})?)", content)))

        # Extract KQL queries from code blocks
        kql_blocks = re.findall(r"```(?:KQL|kql)\s*\n(.*?)```", content, re.DOTALL)
        query = (
            "\n---\n".join(block.strip() for block in kql_blocks) if kql_blocks else ""
        )

        # Determine category from parent directory
        category = (
            file_path.parent.name if file_path.parent != self.kql_path else "General"
        )

        detection = {
            "_source": "kql",
            "_file_path": str(file_path),
            "title": title,
            "name": title,
            "description": description,
            "query": query,
            "category": category,
            "mitre": mitre_techniques,
            "id": f"kql-{file_path.stem}",
        }

        return detection

    def _extract_techniques(self, detection: Dict) -> List[str]:
        """Extract MITRE techniques from a detection"""
        techniques = []

        if detection["_source"] == "sigma":
            tags = detection.get("tags", [])
            for tag in tags:
                if isinstance(tag, str) and tag.startswith("attack.t"):
                    techniques.append(tag.replace("attack.", "").upper())
        elif detection["_source"] == "splunk":
            tags = detection.get("tags", {}).get("mitre_attack_id", [])
            if isinstance(tags, list):
                techniques.extend([t.upper() for t in tags])
        elif detection["_source"] == "kql":
            techs = detection.get("mitre", [])
            if isinstance(techs, list):
                techniques.extend([t.upper() for t in techs])

        return techniques

    async def lint_detections(
        self,
        rule_yaml: Optional[str] = None,
        source_path: Optional[str] = None,
    ) -> Dict:
        """Reject Sigma rules keyed to a specific IP, host, user, or subnet.

        Pass a rule YAML string or a directory of ``.yml`` files. Does not
        run on ``add_source`` / clone; community corpora stay importable.
        """
        return lint_sigma(rule_yaml=rule_yaml, source_path=source_path)

    async def check_detection_candidate(
        self,
        rule_yaml: Optional[str] = None,
        events: Optional[List[Dict]] = None,
        technique_id: Optional[str] = None,
        hostname: Optional[str] = None,
        started_at: Optional[str] = None,
        ended_at: Optional[str] = None,
        **_kwargs: object,
    ) -> Dict:
        """Lint a candidate Sigma rule and replay it against events already in hand.

        ``candidate`` is set only when lint passed and one event matched. The
        missed step stays inside ``candidate`` so the return is not an attack step.
        """
        lint = lint_sigma(rule_yaml=rule_yaml)
        replay = _replay_sigma(rule_yaml or "", events)
        candidate = None
        if lint.get("passed") and replay.get("matched"):
            candidate = {
                "technique_id": technique_id,
                "hostname": hostname,
                "started_at": started_at,
                "ended_at": ended_at,
                "rule_yaml": rule_yaml,
            }
        return {"lint": lint, "replay": replay, "candidate": candidate}

    async def reconstruct_run(self, steps: List[Dict], **_kwargs: object) -> Dict:
        """Correlate an action trace to ingested Findings; return per-step verdicts.

        Extra kwargs (including ``limit`` injected by ``/internal/tools/invoke``)
        are ignored so this does not freeze a later execute-tool JSON shape.
        """
        span = span_for_steps(steps)
        findings = DatabaseDataService().get_findings(
            limit=10000,
            timestamp_start=span[0] if span else None,
            timestamp_end=span[1] if span else None,
        )
        return reconstruct(steps, findings)


# Global instance for reuse
_security_detection_tools = None


def get_security_detection_tools() -> SecurityDetectionsTools:
    """Get or create global instance"""
    global _security_detection_tools
    if _security_detection_tools is None:
        _security_detection_tools = SecurityDetectionsTools()
    return _security_detection_tools


def _replay_sigma(rule_yaml: str, events: Any) -> Dict[str, Any]:
    """One selection of scalar equality and ``|contains``, AND-ed across fields."""
    if not isinstance(events, list):
        return _replay(False, False, "events must be a list")
    fields = _selection_fields(rule_yaml)
    if fields is None:
        return _replay(
            False,
            False,
            "replay only evaluates one selection of equality and |contains",
        )
    matched = any(
        isinstance(event, dict) and _event_matches(event, fields) for event in events
    )
    if matched:
        return _replay(True, True, None)
    return _replay(True, False, "no event matched the selection")


def _replay(evaluated: bool, matched: bool, reason: Optional[str]) -> Dict[str, Any]:
    return {"evaluated": evaluated, "matched": matched, "reason": reason}


def _selection_fields(rule_yaml: str) -> Optional[List[tuple]]:
    try:
        parsed = yaml.safe_load(rule_yaml)
    except yaml.YAMLError:
        return None
    if not isinstance(parsed, dict):
        return None
    detection = parsed.get("detection")
    if not isinstance(detection, dict):
        return None
    selections = {key: value for key, value in detection.items() if key != "condition"}
    if len(selections) != 1:
        return None
    name, body = next(iter(selections.items()))
    condition = detection.get("condition")
    if not isinstance(condition, str) or condition.strip() != name:
        return None
    if not isinstance(body, dict) or not body:
        return None
    fields: List[tuple] = []
    for key, value in body.items():
        field = _field_clause(str(key), value)
        if field is None:
            return None
        fields.append(field)
    return fields


def _field_clause(key: str, value: Any) -> Optional[tuple]:
    parts = key.split("|")
    if len(parts) == 1:
        op = "eq"
    elif len(parts) == 2 and parts[1] == "contains":
        op = "contains"
    else:
        return None
    name = parts[0]
    if not name:
        return None
    if op == "contains":
        if not isinstance(value, str):
            return None
        return name, op, value
    if isinstance(value, bool) or isinstance(value, (str, int, float)):
        return name, op, value
    return None


def _event_matches(event: Dict[str, Any], fields: List[tuple]) -> bool:
    for name, op, expected in fields:
        if name not in event:
            return False
        actual = event[name]
        if op == "eq":
            # bool is an int, so True == 1. A scalar match is the value as written.
            if (
                isinstance(actual, bool) != isinstance(expected, bool)
                or actual != expected
            ):
                return False
            continue
        if not isinstance(actual, str) or expected not in actual:
            return False
    return True
