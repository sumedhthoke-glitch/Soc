"""PDF report generation service."""

import logging
from pathlib import Path
from typing import Dict, List

try:
    from reportlab.lib import colors
    from reportlab.lib.enums import TA_CENTER
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.lib.units import inch
    from reportlab.platypus import (
        PageBreak,
        Paragraph,
        SimpleDocTemplate,
        Spacer,
        Table,
        TableStyle,
    )

    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

logger = logging.getLogger(__name__)


class ReportService:
    """Service for generating PDF reports."""

    def __init__(self):
        """Initialize the report service."""
        if not REPORTLAB_AVAILABLE:
            raise ImportError(
                "reportlab is not installed. Please install it with: pip install reportlab"
            )
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()

    def _setup_custom_styles(self):
        """Set up custom paragraph styles."""
        # Title style
        self.styles.add(
            ParagraphStyle(
                name="CustomTitle",
                parent=self.styles["Heading1"],
                fontSize=24,
                textColor=colors.HexColor("#1a1a1a"),
                spaceAfter=30,
                alignment=TA_CENTER,
            )
        )

        # Heading style
        self.styles.add(
            ParagraphStyle(
                name="CustomHeading",
                parent=self.styles["Heading2"],
                fontSize=16,
                textColor=colors.HexColor("#2c3e50"),
                spaceAfter=12,
                spaceBefore=12,
            )
        )

        # Subheading style
        self.styles.add(
            ParagraphStyle(
                name="CustomSubheading",
                parent=self.styles["Heading3"],
                fontSize=12,
                textColor=colors.HexColor("#34495e"),
                spaceAfter=8,
                spaceBefore=8,
            )
        )

        # Body text style
        self.styles.add(
            ParagraphStyle(
                name="CustomBody",
                parent=self.styles["Normal"],
                fontSize=10,
                textColor=colors.HexColor("#333333"),
                spaceAfter=6,
            )
        )

    def generate_case_report(
        self, output_path: Path, case: Dict, findings: List[Dict]
    ) -> bool:
        """
        Generate a PDF report for a specific case.

        Args:
            output_path: Path to save the PDF file.
            case: Case dictionary.
            findings: List of findings related to the case.

        Returns:
            True if successful, False otherwise.
        """
        try:
            doc = SimpleDocTemplate(
                str(output_path),
                pagesize=letter,
                rightMargin=72,
                leftMargin=72,
                topMargin=72,
                bottomMargin=18,
            )
            story = []

            # Title
            title = case.get("title", "Investigation Case")
            story.append(Paragraph(f"Case Report: {title}", self.styles["CustomTitle"]))
            story.append(Spacer(1, 0.2 * inch))

            # Case metadata
            case_id = case.get("case_id", "N/A")
            created = case.get("created_at", "N/A")
            updated = case.get("updated_at", "N/A")
            status = case.get("status", "N/A")
            priority = case.get("priority", "N/A")
            assignee = case.get("assignee", "Unassigned")

            metadata = [
                ["Case ID:", case_id],
                ["Status:", status.capitalize()],
                ["Priority:", priority.capitalize()],
                ["Assignee:", assignee],
                ["Created:", created.split("T")[0] if "T" in created else created],
                ["Last Updated:", updated.split("T")[0] if "T" in updated else updated],
            ]

            metadata_table = Table(metadata, colWidths=[2 * inch, 4 * inch])
            metadata_table.setStyle(
                TableStyle(
                    [
                        ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#ecf0f1")),
                        ("TEXTCOLOR", (0, 0), (-1, -1), colors.black),
                        ("ALIGN", (0, 0), (0, -1), "LEFT"),
                        ("ALIGN", (1, 0), (1, -1), "LEFT"),
                        ("FONTNAME", (0, 0), (0, -1), "Helvetica-Bold"),
                        ("FONTNAME", (1, 0), (1, -1), "Helvetica"),
                        ("FONTSIZE", (0, 0), (-1, -1), 10),
                        ("BOTTOMPADDING", (0, 0), (-1, -1), 6),
                        ("TOPPADDING", (0, 0), (-1, -1), 6),
                        ("GRID", (0, 0), (-1, -1), 1, colors.grey),
                    ]
                )
            )
            story.append(metadata_table)
            story.append(Spacer(1, 0.3 * inch))

            # Description
            description = case.get("description", "No description provided.")
            story.append(Paragraph("Description", self.styles["CustomHeading"]))
            story.append(Paragraph(description, self.styles["CustomBody"]))
            story.append(Spacer(1, 0.2 * inch))

            # Tags
            tags = case.get("tags", [])
            if tags:
                story.append(Paragraph("Tags", self.styles["CustomHeading"]))
                tags_text = ", ".join(tags)
                story.append(Paragraph(tags_text, self.styles["CustomBody"]))
                story.append(Spacer(1, 0.2 * inch))

            # Timeline
            timeline = case.get("timeline", [])
            if timeline:
                story.append(Paragraph("Timeline", self.styles["CustomHeading"]))
                timeline_data = [["Timestamp", "Event"]]
                for event in timeline:
                    timestamp = event.get("timestamp", "N/A")
                    if "T" in timestamp:
                        timestamp = (
                            timestamp.split("T")[0]
                            + " "
                            + timestamp.split("T")[1].split(".")[0]
                        )
                    timeline_data.append([timestamp, event.get("event", "N/A")])

                timeline_table = Table(
                    timeline_data, colWidths=[2.5 * inch, 3.5 * inch]
                )
                timeline_table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#3498db")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                            ("FONTSIZE", (0, 0), (-1, 0), 10),
                            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                            ("GRID", (0, 0), (-1, -1), 1, colors.grey),
                        ]
                    )
                )
                story.append(timeline_table)
                story.append(Spacer(1, 0.2 * inch))

            # Notes
            notes = case.get("notes", [])
            if notes:
                story.append(
                    Paragraph("Investigation Notes", self.styles["CustomHeading"])
                )
                for note in notes:
                    note_text = note.get("text", note.get("content", "N/A"))
                    note_timestamp = note.get("timestamp", "N/A")
                    if "T" in note_timestamp:
                        note_timestamp = note_timestamp.split("T")[0]
                    story.append(
                        Paragraph(
                            f"<b>{note_timestamp}:</b> {note_text}",
                            self.styles["CustomBody"],
                        )
                    )
                    story.append(Spacer(1, 0.1 * inch))
                story.append(Spacer(1, 0.2 * inch))

            # Activities
            activities = case.get("activities", [])
            if activities:
                story.append(Paragraph("Case Activities", self.styles["CustomHeading"]))
                activities_data = [["Timestamp", "Type", "Description"]]
                for activity in activities:
                    timestamp = activity.get("timestamp", "N/A")
                    if "T" in timestamp:
                        timestamp = (
                            timestamp.split("T")[0]
                            + " "
                            + timestamp.split("T")[1].split(".")[0]
                        )
                    activity_type = (
                        activity.get("activity_type", "N/A").replace("_", " ").title()
                    )
                    description = activity.get("description", "N/A")[:100]
                    activities_data.append([timestamp, activity_type, description])

                activities_table = Table(
                    activities_data, colWidths=[2 * inch, 1.5 * inch, 2.5 * inch]
                )
                activities_table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#9b59b6")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                            ("FONTSIZE", (0, 0), (-1, 0), 10),
                            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                            ("GRID", (0, 0), (-1, -1), 1, colors.grey),
                            ("FONTSIZE", (0, 1), (-1, -1), 9),
                        ]
                    )
                )
                story.append(activities_table)
                story.append(Spacer(1, 0.2 * inch))

            # Resolution Steps
            resolution_steps = case.get("resolution_steps", [])
            if resolution_steps:
                story.append(
                    Paragraph("Resolution Steps", self.styles["CustomHeading"])
                )
                for i, step in enumerate(resolution_steps, 1):
                    story.append(
                        Paragraph(
                            f"Step {i}: {step.get('description', 'N/A')}",
                            self.styles["CustomSubheading"],
                        )
                    )

                    step_info = [
                        ["Field", "Value"],
                        ["Timestamp", step.get("timestamp", "N/A")],
                        ["Action Taken", step.get("action_taken", "N/A")],
                    ]

                    result = step.get("result", "")
                    if result:
                        step_info.append(["Result", result])

                    step_table = Table(step_info, colWidths=[2 * inch, 4 * inch])
                    step_table.setStyle(
                        TableStyle(
                            [
                                (
                                    "BACKGROUND",
                                    (0, 0),
                                    (-1, 0),
                                    colors.HexColor("#27ae60"),
                                ),
                                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                                ("FONTSIZE", (0, 0), (-1, 0), 10),
                                ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                                ("GRID", (0, 0), (-1, -1), 1, colors.grey),
                                ("FONTSIZE", (0, 1), (-1, -1), 9),
                            ]
                        )
                    )
                    story.append(step_table)
                    story.append(Spacer(1, 0.15 * inch))
                story.append(Spacer(1, 0.2 * inch))

            # Findings
            story.append(
                Paragraph(
                    f"Related Findings ({len(findings)})", self.styles["CustomHeading"]
                )
            )

            if findings:
                findings_data = [
                    [
                        "Finding ID",
                        "Severity",
                        "Data Source",
                        "Anomaly Score",
                        "MITRE Techniques",
                    ]
                ]
                for finding in findings:
                    finding_id = finding.get("finding_id", "N/A")
                    severity = finding.get("severity", "N/A")
                    data_source = finding.get("data_source", "N/A")
                    anomaly_score = f"{float(finding.get('anomaly_score') or 0):.3f}"

                    # Get top MITRE techniques
                    mitre_preds = finding.get("mitre_predictions") or {}
                    if mitre_preds:
                        top_techs = sorted(
                            mitre_preds.items(),
                            key=lambda x: float(x[1] or 0),
                            reverse=True,
                        )[:3]
                        tech_str = ", ".join([t[0] for t in top_techs])
                    else:
                        tech_str = "None"

                    findings_data.append(
                        [finding_id, severity, data_source, anomaly_score, tech_str]
                    )

                findings_table = Table(
                    findings_data,
                    colWidths=[1.5 * inch, 1 * inch, 1 * inch, 1 * inch, 1.5 * inch],
                )
                findings_table.setStyle(
                    TableStyle(
                        [
                            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#e74c3c")),
                            ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                            ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                            ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                            ("FONTSIZE", (0, 0), (-1, 0), 9),
                            ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                            ("GRID", (0, 0), (-1, -1), 1, colors.grey),
                            ("FONTSIZE", (0, 1), (-1, -1), 8),
                            (
                                "ROWBACKGROUNDS",
                                (0, 1),
                                (-1, -1),
                                [colors.white, colors.HexColor("#f8f9fa")],
                            ),
                        ]
                    )
                )
                story.append(findings_table)
                story.append(PageBreak())

                # Detailed findings
                story.append(Paragraph("Finding Details", self.styles["CustomHeading"]))

                for i, finding in enumerate(findings, 1):
                    story.append(
                        Paragraph(
                            f"Finding {i}: {finding.get('finding_id', 'N/A')}",
                            self.styles["CustomSubheading"],
                        )
                    )

                    finding_info = [
                        ["Field", "Value"],
                        ["Finding ID", finding.get("finding_id", "N/A")],
                        ["Timestamp", finding.get("timestamp", "N/A")],
                        ["Severity", finding.get("severity", "N/A")],
                        ["Data Source", finding.get("data_source", "N/A")],
                        ["Anomaly Score", f"{finding.get('anomaly_score', 0):.3f}"],
                        ["Cluster ID", finding.get("cluster_id", "None")],
                    ]

                    # Entity context
                    entity_context = finding.get("entity_context") or {}
                    if entity_context:
                        for key, value in entity_context.items():
                            finding_info.append([f"Entity: {key}", str(value)])

                    # MITRE techniques
                    mitre_preds = finding.get("mitre_predictions") or {}
                    if mitre_preds:
                        for tech_id, confidence in sorted(
                            mitre_preds.items(),
                            key=lambda x: float(x[1] or 0),
                            reverse=True,
                        )[:10]:
                            finding_info.append(
                                [f"MITRE: {tech_id}", f"{float(confidence or 0):.3f}"]
                            )

                    finding_table = Table(finding_info, colWidths=[2 * inch, 4 * inch])
                    finding_table.setStyle(
                        TableStyle(
                            [
                                (
                                    "BACKGROUND",
                                    (0, 0),
                                    (-1, 0),
                                    colors.HexColor("#95a5a6"),
                                ),
                                ("TEXTCOLOR", (0, 0), (-1, 0), colors.whitesmoke),
                                ("ALIGN", (0, 0), (-1, -1), "LEFT"),
                                ("FONTNAME", (0, 0), (-1, 0), "Helvetica-Bold"),
                                ("FONTSIZE", (0, 0), (-1, 0), 9),
                                ("BACKGROUND", (0, 1), (-1, -1), colors.white),
                                ("GRID", (0, 0), (-1, -1), 1, colors.grey),
                                ("FONTSIZE", (0, 1), (-1, -1), 8),
                            ]
                        )
                    )
                    story.append(finding_table)
                    story.append(Spacer(1, 0.1 * inch))
            else:
                story.append(
                    Paragraph(
                        "No findings associated with this case.",
                        self.styles["CustomBody"],
                    )
                )

            # Build PDF
            doc.build(story)
            logger.info(f"Generated case report: {output_path}")
            return True

        except Exception as e:
            logger.error(f"Error generating case report: {e}", exc_info=True)
            return False
