"""joe-sandbox integration slice."""
