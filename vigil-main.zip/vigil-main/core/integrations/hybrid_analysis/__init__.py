"""hybrid-analysis integration slice."""
