"""carbon-black integration slice."""
