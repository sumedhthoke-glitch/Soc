"""misp integration slice."""
