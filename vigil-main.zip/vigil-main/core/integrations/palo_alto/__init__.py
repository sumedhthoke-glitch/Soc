"""palo-alto integration slice."""
