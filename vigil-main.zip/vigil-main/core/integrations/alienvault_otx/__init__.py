"""alienvault-otx integration slice."""
