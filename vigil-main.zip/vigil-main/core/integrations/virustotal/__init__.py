"""virustotal integration slice."""
