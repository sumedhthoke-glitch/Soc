"""microsoft-teams integration slice."""
