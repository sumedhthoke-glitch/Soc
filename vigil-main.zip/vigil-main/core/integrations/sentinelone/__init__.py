"""sentinelone integration slice."""
