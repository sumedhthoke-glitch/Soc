"""cape-sandbox integration slice."""
