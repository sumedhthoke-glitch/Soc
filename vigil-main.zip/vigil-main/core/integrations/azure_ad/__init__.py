"""azure-ad integration slice."""
