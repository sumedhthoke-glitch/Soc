"""shodan integration slice."""
