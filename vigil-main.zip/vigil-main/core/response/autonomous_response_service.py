"""Autonomous response service with approval workflow integration."""

import logging
from typing import Any, Dict, List, Optional

from core.agents.builtins import AgentId
from core.response.approval_service import ActionStatus, ActionType, ApprovalService
from core.response.config import ResponseConfig

logger = logging.getLogger(__name__)


class AutonomousResponseService:
    """Service for managing autonomous threat response with approval workflow."""

    def __init__(
        self,
        approvals: Optional[ApprovalService] = None,
        config: Optional[ResponseConfig] = None,
    ):
        """Initialize autonomous response service.

        ``config`` defaults to the approval service's band so the two never
        compare against different lines; the no-arg form reads Settings.
        """
        self.approval_service = approvals or ApprovalService(config=config)
        self.config = config or self.approval_service.config

    def correlate_alerts(
        self,
        tempo_flow_alert: Optional[Dict] = None,
        crowdstrike_alert: Optional[Dict] = None,
        splunk_results: Optional[List[Dict]] = None,
    ) -> Dict:
        """
        Correlate alerts from multiple sources and calculate confidence score.

        Args:
            tempo_flow_alert: Alert from Tempo Flow
            crowdstrike_alert: Alert from CrowdStrike
            splunk_results: Results from Splunk queries

        Returns:
            Correlation result with confidence score and reasoning
        """
        confidence = 0.0
        evidence = []
        indicators = []
        reasoning = []

        # Correlate Tempo Flow alerts
        if tempo_flow_alert:
            evidence.append(
                f"Tempo Flow: {tempo_flow_alert.get('finding_id', 'unknown')}"
            )

            severity = tempo_flow_alert.get("severity", "").lower()
            if severity in ["high", "critical"]:
                confidence += 0.15
                reasoning.append(f"High severity detection in Tempo Flow ({severity})")

            # Check for specific attack patterns
            mitre_predictions = tempo_flow_alert.get("mitre_predictions", {})
            if any(t.startswith("T1486") for t in mitre_predictions):  # Ransomware
                confidence += 0.25
                reasoning.append("Ransomware behavior detected (T1486)")
                indicators.append("ransomware")

            if any(t.startswith("T1071") for t in mitre_predictions):  # C2
                confidence += 0.20
                reasoning.append("C2 communication detected (T1071)")
                indicators.append("c2_communication")

            if any(
                t.startswith("T1021") for t in mitre_predictions
            ):  # Lateral movement
                confidence += 0.15
                reasoning.append("Lateral movement detected (T1021)")
                indicators.append("lateral_movement")

        # Correlate CrowdStrike alerts
        if crowdstrike_alert:
            cs_alerts = crowdstrike_alert.get("alerts", [])
            if cs_alerts:
                evidence.append(f"CrowdStrike: {len(cs_alerts)} alert(s)")

                for alert in cs_alerts:
                    severity = alert.get("severity", "").lower()
                    if severity == "critical":
                        confidence += 0.15
                        reasoning.append("Critical severity in CrowdStrike")

                    detection_type = alert.get("detection_type", "").lower()
                    if detection_type == "malware":
                        confidence += 0.20
                        reasoning.append(
                            f"Malware detected: {alert.get('description', '')}"
                        )
                        indicators.append("malware")

                    # Check if already isolated
                    if alert.get("isolated", False):
                        reasoning.append("Host already isolated in CrowdStrike")

        # Correlate Splunk results
        if splunk_results and len(splunk_results) > 0:
            evidence.append(f"Splunk: {len(splunk_results)} event(s)")

            # High volume of events indicates active threat
            if len(splunk_results) > 50:
                confidence += 0.10
                reasoning.append(f"High volume of events ({len(splunk_results)})")

        # Time correlation bonus
        if tempo_flow_alert and crowdstrike_alert:
            # If alerts are within 5 minutes, add correlation bonus
            confidence += 0.10
            reasoning.append("Temporal correlation between multiple sources")

        # Cap confidence at 1.0
        confidence = min(confidence, 1.0)

        return {
            "confidence": confidence,
            "indicators": indicators,
            "evidence": evidence,
            "reasoning": reasoning,
            "recommendation": self._get_recommendation(confidence, indicators),
        }

    def _get_recommendation(self, confidence: float, indicators: List[str]) -> str:
        """Get recommendation based on confidence and indicators."""
        if confidence >= self.config.confidence_threshold:
            return "AUTO-ISOLATE: Confidence threshold met for automatic isolation"
        elif confidence >= self.config.review_threshold:
            return "ISOLATE WITH APPROVAL: High confidence, recommend isolation with quick approval"
        elif confidence >= self.config.monitor_threshold:
            return "MANUAL REVIEW: Moderate confidence, requires analyst review"
        else:
            return "MONITOR: Low confidence, continue monitoring"

    def create_isolation_action(
        self,
        ip_address: str,
        hostname: Optional[str],
        confidence: float,
        reason: str,
        evidence: List[str],
        correlation_data: Dict,
    ) -> Optional[Dict]:
        """
        Create an isolation action (auto-executes when the approval gate
        approves it, i.e. at or above ``config.confidence_threshold``).

        Args:
            ip_address: Target IP address
            hostname: Target hostname (optional)
            confidence: Confidence score (0.0-1.0)
            reason: Reason for isolation
            evidence: List of evidence IDs
            correlation_data: Data from correlation analysis

        Returns:
            Action result
        """
        # Key on the IP when known; an IP-less finding (ip_address == "unknown")
        # keys on hostname instead, so distinct IP-less hosts get distinct rows
        # rather than colliding on the literal string "unknown".
        target_key = (
            ip_address if ip_address and ip_address != "unknown" else f"host:{hostname}"
        )

        try:
            action, inserted = self.approval_service._put_action(
                action_type=ActionType.ISOLATE_HOST,
                title=f"Isolate Host: {hostname or ip_address}",
                description=f"Network isolation of compromised host based on correlated detections.\n\n"
                f"Indicators: {', '.join(correlation_data.get('indicators', []))}\n"
                f"Reasoning: {' | '.join(correlation_data.get('reasoning', []))}",
                target=ip_address,
                confidence=confidence,
                reason=reason,
                evidence=evidence,
                created_by=AgentId.AUTO_RESPONDER.value,
                parameters={"hostname": hostname, "correlation": correlation_data},
                idempotency_key=f"{ActionType.ISOLATE_HOST.value}:{target_key}",
            )

            if not inserted:
                if action.status == ActionStatus.EXECUTED.value:
                    return {
                        "status": "executed",
                        "reused": True,
                        "action_id": action.action_id,
                        "message": f"Host {hostname or ip_address} already isolated",
                        "confidence": action.confidence,
                        "result": action.execution_result,
                    }
                return {
                    "status": action.status,
                    "reused": True,
                    "action_id": action.action_id,
                    "message": f"Isolation already recorded for {hostname or ip_address}",
                    "confidence": action.confidence,
                    "requires_approval": action.requires_approval,
                    "result": action.execution_result,
                }

            if action.status == ActionStatus.APPROVED.value:
                logger.info(
                    f"Action {action.action_id} auto-approved (confidence: {confidence:.2%})"
                )

                execution_result = self._execute_isolation(
                    ip_address, hostname, reason, confidence
                )

                if execution_result.get("success"):
                    self.approval_service.mark_executed(
                        action.action_id, execution_result
                    )
                    return {
                        "status": "executed",
                        "action_id": action.action_id,
                        "message": f"Host {hostname or ip_address} isolated automatically",
                        "confidence": confidence,
                        "result": execution_result,
                    }

                self.approval_service.mark_failed(
                    action.action_id,
                    execution_result.get("error", "Unknown error"),
                )
                return {
                    "status": ActionStatus.FAILED.value,
                    "action_id": action.action_id,
                    "message": execution_result.get("message")
                    or f"Isolation of {hostname or ip_address} was not executed",
                    "confidence": confidence,
                    "result": execution_result,
                }
            else:
                logger.info(
                    f"Action {action.action_id} pending approval (confidence: {confidence:.2%})"
                )
                return {
                    "status": "pending_approval",
                    "action_id": action.action_id,
                    "message": "Isolation action created, awaiting analyst approval",
                    "confidence": confidence,
                    "requires_approval": True,
                }

        except Exception as e:
            logger.error(f"Error creating isolation action: {e}")
            return {"error": str(e)}

    def _execute_isolation(
        self, ip_address: str, hostname: Optional[str], reason: str, confidence: float
    ) -> Dict:
        """
        Report that host isolation has no executor.

        No EDR containment call is wired. A success result would record a
        containment that never happened.
        """
        logger.info(
            f"Isolation not executed: {hostname or ip_address} "
            f"(confidence: {confidence:.2%}); no EDR executor"
        )
        return {
            "success": False,
            "error": "unsupported_action_type",
            "message": "No EDR executor is configured for host isolation",
        }

    def execute_approved_actions(self) -> List[Dict]:
        """
        Execute all approved actions that haven't been executed yet.

        Returns:
            List of execution results
        """
        try:
            # Get approved but not executed actions
            approved_actions = self.approval_service.list_actions(
                status=ActionStatus.APPROVED
            )
            results = []

            for action in approved_actions:
                # Skip if already executed
                if action.executed_at:
                    continue

                params = action.parameters or {}
                result: Optional[Dict] = None

                if action.action_type == "isolate_host":
                    result = self._execute_isolation(
                        ip_address=action.target,
                        hostname=params.get("hostname"),
                        reason=action.reason,
                        confidence=action.confidence,
                    )
                elif action.action_type in (
                    "waf_block",
                    "gateway_block",
                    "access_revoke",
                ):
                    result = self._execute_cloudflare_action(
                        action_type=action.action_type,
                        target=action.target,
                        reason=action.reason,
                        parameters=params,
                    )

                if result is None:
                    # Unknown action type — leave for another executor or manual handling.
                    continue

                if result.get("success"):
                    self.approval_service.mark_executed(action.action_id, result)
                else:
                    self.approval_service.mark_failed(
                        action.action_id, result.get("error", "Unknown error")
                    )

                results.append(
                    {
                        "action_id": action.action_id,
                        "action_type": action.action_type,
                        "target": action.target,
                        "result": result,
                    }
                )

            return results

        except Exception as e:
            logger.error(f"Error executing approved actions: {e}")
            return []

    # ------------------------------------------------------------------
    # Cloudflare action factories + executor
    # ------------------------------------------------------------------

    def _execute_cloudflare_action(
        self,
        action_type: str,
        target: str,
        reason: str,
        parameters: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Execute an approved Cloudflare action via the REST helpers in core/integrations/cloudflare/tool.py."""
        try:
            from core.config import get_integration_config, is_integration_enabled
        except Exception as e:  # noqa: BLE001
            return {"success": False, "error": f"config import failed: {e}"}

        if not is_integration_enabled("cloudflare"):
            return {
                "success": False,
                "error": "cloudflare_integration_disabled",
                "message": "Enable the Cloudflare integration in Settings to execute this action.",
            }

        cfg = get_integration_config("cloudflare") or {}
        api_token = cfg.get("api_token")
        account_id = cfg.get("account_id")
        if not api_token:
            return {"success": False, "error": "cloudflare api_token not configured"}

        # Lazy import to avoid forcing the MCP package on environments that
        # never enable Cloudflare.
        try:
            from core.integrations.cloudflare import tool as cf_tool
        except Exception as e:  # noqa: BLE001
            return {
                "success": False,
                "error": f"core.integrations.cloudflare.tool unavailable: {e}",
            }

        try:
            if action_type == "waf_block":
                return cf_tool._waf_block_ip(
                    api_token=api_token,
                    account_id=account_id,
                    ip=parameters.get("ip") or target,
                    reason=reason,
                    mode=parameters.get("mode", "block"),
                )
            if action_type == "gateway_block":
                return cf_tool._gateway_block_domain(
                    api_token=api_token,
                    account_id=account_id,
                    domain=parameters.get("domain") or target,
                    reason=reason,
                    rule_name=parameters.get("rule_name"),
                )
            if action_type == "access_revoke":
                return cf_tool._access_revoke_session(
                    api_token=api_token,
                    account_id=account_id,
                    email=parameters.get("email") or target,
                    reason=reason,
                )
            return {
                "success": False,
                "error": f"unknown cloudflare action {action_type}",
            }
        except Exception as e:  # noqa: BLE001
            logger.exception("Cloudflare action %s failed", action_type)
            return {"success": False, "error": str(e)}
