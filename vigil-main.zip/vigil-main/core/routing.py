"""Declarative mount metadata for API routers.

Every router module exports a ``router`` and a ``ROUTER_META`` describing how
that router should be mounted. It lives with its domain as
``core/<domain>/<name>_router.py``, or — until that domain is in ``core/`` —
parked under ``services/api/routers/``. ``services/api/discovery.py`` scans both
locations and mounts them, so adding a router needs no edit to
``services/api/main.py`` (issues #478, #488).

This module is deliberately a leaf: it imports nothing from ``services.api.main``
or from any router module, so all 42 routers can import ``Auth`` and
``RouterMeta`` without an import cycle.

``ROUTER_META`` is **mandatory**. There is no convention-based fallback,
because filename-inferred prefixes would be wrong for 21 of the 42 modules
(``ai_config`` -> ``/api/ai``, ``case_metrics`` -> ``/api/cases/metrics``,
``llm_providers`` -> ``/api/llm/providers``, ``ingestion`` -> ``/api/ingest``,
and 17 more). A module without ``ROUTER_META`` is a startup error, not a
silently mis-mounted route.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Annotated, Callable, Generator, Sequence

from fastapi import Depends
from sqlalchemy.orm import Session

from core.storage.unit_of_work import unit_of_work


class Auth(Enum):
    """Why a router has the auth posture it has.

    Recording the reason rather than a bare boolean means the five
    non-``REQUIRED`` routers each carry their justification in code. A wrong
    value is a visible claim a reviewer can challenge, rather than an
    omission nobody notices.
    """

    #: Mount with the shared authenticated-active-user dependency. The
    #: default posture; 37 of 42 routers.
    REQUIRED = "required"

    #: The router enforces its own auth internally — a nested router with
    #: its own ``dependencies``, a per-handler ``Depends(...)``, or a bearer
    #: API-key check. Do not attach the shared dependency: doing so would
    #: break login (``auth``) or the inbound bearer path (``vstrike``).
    ROUTER_MANAGED = "router_managed"

    #: Inbound third-party webhook receiver. Unauthenticated by session
    #: because the caller is a machine; the endpoint itself must do
    #: HMAC/API-key validation. Always pair with ``enabled`` so the receiver
    #: is off unless explicitly switched on.
    PUBLIC_WEBHOOK = "public_webhook"


@dataclass(frozen=True)
class RouterMeta:
    """How to mount one router.

    :param prefix: Path prefix **excluding** any deployment context path;
        the mounting code prepends ``VIGIL_CONTEXT_PATH``. Declared rather
        than inferred — see the module docstring.
    :param tags: OpenAPI tags.
    :param auth: Auth posture. See :class:`Auth`.
    :param reason: Why this router deviates from ``Auth.REQUIRED``. Mandatory
        for every non-``REQUIRED`` posture and rejected for ``REQUIRED``,
        where there is nothing to justify. A field rather than a comment so
        the justification cannot be deleted or omitted silently. To enumerate
        every deviation and its rationale, iterate
        ``services.api.discovery.load_router_specs()`` — a bare ``grep reason=``
        false-matches unrelated kwargs such as ``change_reason=``. The
        enumeration is asserted by
        ``tests/unit/test_router_discovery.py::test_every_non_required_router_has_a_reason``.
    :param enabled: Optional predicate evaluated at mount time. When it
        returns false the router is not mounted at all. Required for
        ``PUBLIC_WEBHOOK`` routers so an inbound receiver cannot be exposed
        by default.
    :param extra_dependencies: Additional ``Depends(...)`` beyond the auth
        dependency — e.g. the per-router rate limit on ``claude``.
    :param legacy_prefixes: Additional prefixes to mount the *same* router at,
        for backward compatibility. A versioned router lives at ``prefix``
        (``/api/v1/findings``) and lists the pre-version path
        (``/api/findings``) here, so existing callers keep working while a new
        caller uses the versioned path. One set of handlers, mounted twice —
        no duplicated route bodies. The legacy mount is dropped once callers
        have moved; until then both resolve identically.
    """

    prefix: str
    tags: Sequence[str]
    auth: Auth
    reason: str = ""
    enabled: Callable[[], bool] | None = None
    extra_dependencies: Sequence = field(default_factory=tuple)
    legacy_prefixes: Sequence[str] = field(default_factory=tuple)

    def __post_init__(self) -> None:
        if not self.prefix.startswith("/"):
            raise ValueError(f"prefix must start with '/': {self.prefix!r}")
        if self.prefix.endswith("/"):
            raise ValueError(f"prefix must not end with '/': {self.prefix!r}")
        for legacy in self.legacy_prefixes:
            if not legacy.startswith("/"):
                raise ValueError(f"legacy prefix must start with '/': {legacy!r}")
            if legacy.endswith("/"):
                raise ValueError(f"legacy prefix must not end with '/': {legacy!r}")
            if legacy == self.prefix:
                raise ValueError(
                    f"legacy prefix {legacy!r} equals prefix; a router cannot "
                    "be mounted at the same path twice"
                )
        if self.auth is Auth.PUBLIC_WEBHOOK and self.enabled is None:
            # An inbound receiver that is always mounted is exactly the
            # accident this refactor must not introduce.
            raise ValueError(
                f"PUBLIC_WEBHOOK router at {self.prefix!r} must declare "
                "`enabled` so it cannot be exposed by default"
            )
        if self.auth is not Auth.REQUIRED and not self.reason.strip():
            # Weakening auth is the one change here that should never be
            # possible to make quietly.
            raise ValueError(
                f"router at {self.prefix!r} declares auth={self.auth.name} "
                "but no `reason`. Every deviation from Auth.REQUIRED must say "
                "why in the metadata, not in a comment."
            )
        if self.auth is Auth.REQUIRED and self.reason.strip():
            # Otherwise `reason` drifts into a general-purpose notes field and
            # stops meaning "here is why auth is weaker than the default".
            raise ValueError(
                f"router at {self.prefix!r} is Auth.REQUIRED and needs no "
                "`reason`; use a normal comment for other notes."
            )

    @property
    def is_enabled(self) -> bool:
        return True if self.enabled is None else bool(self.enabled())


def request_unit_of_work() -> Generator[Session, None, None]:
    """Yield a session whose transaction spans the whole request.

    Commits once if the endpoint returns normally, rolls back if it raises
    (``HTTPException`` included), and always closes. Endpoints and the services
    they call must not commit or roll back themselves.
    """
    with unit_of_work() as session:
        yield session


# Depend on this alias rather than writing out ``Depends(request_unit_of_work)``.
# The ``scope="function"`` is load-bearing: with the default request scope,
# teardown runs *after* the response has been sent, so a failed commit returns
# the success body with a 200 while the write is rolled back. Function scope
# closes the boundary before the response is emitted, turning that into a 500.
UnitOfWorkSession = Annotated[Session, Depends(request_unit_of_work, scope="function")]
