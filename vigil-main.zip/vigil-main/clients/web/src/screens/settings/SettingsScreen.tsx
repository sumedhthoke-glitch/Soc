import { useEffect, useMemo } from 'react'
import { useSearchParams } from 'react-router-dom'
import { Icon, type IconName } from '../../shared/icons'
import type { ConsoleScreenProps, SettingsSectionKey } from '../../shared/types'
import { useToast } from '../../shell/toast'
import AppearanceSection from './AppearanceSection'
import GeneralSection from './GeneralSection'
import SystemSection from './SystemSection'
import FederationSection from './FederationSection'
import UsersSection from './UsersSection'
import AutoInvestigateSection from './AutoInvestigateSection'
import DeveloperSection from './DeveloperSection'
import AiConfigSection from './AiConfigSection'
import ServicesSection from './ServicesSection'
import IntegrationsSection from './IntegrationsSection'
import SlaPoliciesSection from './SlaPoliciesSection'
import type { SectionProps } from './types'

const IS_DEV_MODE = import.meta.env.VITE_DEV_MODE === 'true'

interface SectionDef {
  key: SettingsSectionKey
  label: string
  icon: IconName
  devOnly?: boolean
  Component?: (props: SectionProps) => JSX.Element
}

const SECTIONS: SectionDef[] = [
  { key: 'appearance', label: 'Appearance', icon: 'palette', Component: AppearanceSection },
  { key: 'ai-config', label: 'AI Config', icon: 'sparkle', Component: AiConfigSection },
  { key: 'services', label: 'Services', icon: 'play', Component: ServicesSection },
  { key: 'integrations', label: 'Integrations', icon: 'link', Component: IntegrationsSection },
  { key: 'users', label: 'Users', icon: 'lock', Component: UsersSection },
  { key: 'sla', label: 'SLA Policies', icon: 'clock', Component: SlaPoliciesSection },
  { key: 'autoinvestigate', label: 'Auto Investigate', icon: 'bolt', Component: AutoInvestigateSection },
  { key: 'federation', label: 'Federation', icon: 'graph', Component: FederationSection },
  { key: 'system', label: 'System', icon: 'wrench', Component: SystemSection },
  { key: 'general', label: 'General', icon: 'gear', Component: GeneralSection },
  { key: 'dev', label: 'Developer', icon: 'fork', devOnly: true, Component: DeveloperSection },
]

export default function SettingsScreen({ setViewFull }: ConsoleScreenProps) {
  const sections = useMemo(() => SECTIONS.filter((s) => !s.devOnly || IS_DEV_MODE), [])
  const [searchParams, setSearchParams] = useSearchParams()
  const sectionParam = searchParams.get('section')
  const sectionKeys = useMemo(() => new Set(sections.map((s) => s.key)), [sections])
  // falls back to Appearance for a missing / unknown / dev-gated key
  const active: SettingsSectionKey =
    sectionParam && sectionKeys.has(sectionParam as SettingsSectionKey)
      ? (sectionParam as SettingsSectionKey)
      : 'appearance'
  // results surface through the shell-wide toast, not a settings-local banner
  const { notify } = useToast()

  useEffect(() => {
    setViewFull(true)
    return () => setViewFull(false)
  }, [setViewFull])

  const current = sections.find((s) => s.key === active) ?? sections[0]
  const Section = current.Component

  return (
    <div className="settings-wrap">
      <nav className="settings-nav">
        {sections.map((s) => (
          <button
            key={s.key}
            className={`settings-nav-item${s.key === active ? ' active' : ''}`}
            onClick={() => setSearchParams({ section: s.key }, { replace: true })}
          >
            <Icon name={s.icon} size={16} />
            <span>{s.label}</span>
          </button>
        ))}
      </nav>

      <div className="settings-content">
        {Section ? (
          <Section notify={notify} />
        ) : (
          <div className="settings-placeholder">
            <Icon name={current.icon} size={28} />
            <span className="text-sm">{current.label} settings are not available yet.</span>
            <span className="text-xs">Configure this from the API for now.</span>
          </div>
        )}
      </div>
    </div>
  )
}
