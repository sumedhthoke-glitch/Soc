import { Fragment, useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from 'react'
import { Icon } from '../../shared/icons'
import { Pie, Hbars } from '../../shared/charts'
import { useFindings, useDashboardKpis } from './useFindings'
import type { Finding } from '../../data/data'
import { formatFindingScore } from '../../data/mappers'
import { useAttack, type LayerVerdict } from './useAttack'
import { useTimeline } from './useTimeline'
import { EmptyState, FilterButton, FilterGroup } from '../../shared/ui'
import { DataTable, useTableSort, searchRows, sortRows, ColumnPicker } from '../../shared/DataTable'
import { baseFindingColumns, extraFindingColumns } from './findingsColumns'
import FindingPopup from './FindingPopup'
import ExclusionsSection from './ExclusionsSection'
import type { ExclusionView } from '../../services/api'
import AttackTechniqueFindings from './AttackTechniqueFindings'
import { SEV_COLOR, TL_MONTHS, type TimelineEvent } from './attackData'
import type { ConsoleScreenProps } from '../../shared/types'
import { useToast } from '../../shell/toast'
import { downloadFindingsCsv } from './findingsExport'
import {
  isFindingsSeverityFilter,
  loadFindingsViewPreferences,
  saveFindingsViewPreferences,
} from './findingsPreferences'

type DashTab = 'findings' | 'attack' | 'timeline'

export default function DashboardScreen({ openChat, goSettings }: ConsoleScreenProps) {
  const [tab, setTab] = useState<DashTab>('findings')
  const tabs: [DashTab, string][] = [
    ['findings', 'Findings'],
    ['attack', 'ATT&CK'],
    ['timeline', 'Timeline'],
  ]
  return (
    <>
      <div className="flex items-center gap-3 flex-wrap px-[22px] py-[13px] border-b border-line tabbar">
        <div className="tabs" role="tablist" aria-label="Dashboard views">
          {tabs.map(([k, label]) => (
            <button
              key={k}
              role="tab"
              aria-selected={tab === k}
              className={`tab${tab === k ? ' active' : ''}`}
              onClick={() => setTab(k)}
            >
              {label}
            </button>
          ))}
        </div>
      </div>
      {tab === 'findings' && <FindingsTab openChat={openChat} goSettings={goSettings} />}
      {tab === 'attack' && <AttackTab />}
      {tab === 'timeline' && <TimelineTab />}
    </>
  )
}

const NDASH = '—'

function findingPrompt(f: Finding): string {
  const parts = [`${f.sev} severity`, `MITRE ${f.tech}${f.tactic !== NDASH ? ` (${f.tactic})` : ''}`, `source ${f.src}`]
  if (f.host !== NDASH) parts.push(`host ${f.host}`)
  if (f.user !== NDASH) parts.push(`user ${f.user}`)
  parts.push(`anomaly score ${formatFindingScore(f.score)}`)
  return `Investigate finding ${f.id} — ${parts.join(', ')}. What happened and what should I do next?`
}

const EXCLUSION_VIEWS: { value: ExclusionView; label: string }[] = [
  { value: 'hide', label: 'Hidden' },
  { value: 'include', label: 'Shown' },
  { value: 'only', label: 'Only excluded' },
]

function isExclusionView(value: string): value is ExclusionView {
  return EXCLUSION_VIEWS.some((v) => v.value === value)
}

function FindingsTab({ openChat, goSettings }: Pick<ConsoleScreenProps, 'openChat' | 'goSettings'>) {
  const { notify } = useToast()
  // analyst-excluded IPs stay out of the queue unless asked for
  const [exView, setExView] = useState<ExclusionView>('hide')
  const [exclusionsKey, setExclusionsKey] = useState(0)
  const { rows, phase, error, reload } = useFindings(exView)
  const { kpis, reload: reloadKpis } = useDashboardKpis()
  const [initialPreferences] = useState(loadFindingsViewPreferences)
  const [query, setQuery] = useState('')
  const [sev, setSev] = useState(initialPreferences.severity)
  const [src, setSrc] = useState(initialPreferences.source)
  const [detailId, setDetailId] = useState<string | null>(null)
  const [pageSize, setPageSize] = useState(10)
  const [page, setPage] = useState(1)
  // null = untouched, so use each column's default visibility. An empty Set is
  // meaningfully different: the user unhid everything.
  const [hiddenCols, setHiddenCols] = useState<Set<string> | null>(
    initialPreferences.hiddenColumns ? new Set(initialPreferences.hiddenColumns) : null,
  )

  // derived from whatever entity keys the rows carry, so a new source needs no
  // code change here
  const allColumns = useMemo(() => {
    const base = baseFindingColumns(
      (f) => setDetailId(f.id),
      (f) => openChat(findingPrompt(f)),
    )
    const extra = extraFindingColumns(rows)
    return [...base.slice(0, -1), ...extra, base[base.length - 1]]
  }, [rows, openChat])

  const defaultHidden = useMemo(
    () => new Set(allColumns.filter((c) => c.visible === false).map((c) => c.key)),
    [allColumns],
  )
  const effectiveHidden = hiddenCols ?? defaultHidden
  const columns = useMemo(
    () => allColumns.filter((c) => !effectiveHidden.has(c.key)),
    [allColumns, effectiveHidden],
  )

  const { sort, toggle: toggleSort } = useTableSort(allColumns, { key: 'time', dir: 'desc' })

  const srcOptions = useMemo(() => {
    const set = Array.from(new Set(rows.map((f) => f.src).filter((s) => s && s !== '—'))).sort()
    return [{ value: 'any', label: 'Any' }, ...set.map((s) => ({ value: s, label: s }))]
  }, [rows])

  useEffect(() => {
    if (phase === 'ready' && src !== 'any' && !srcOptions.some((option) => option.value === src)) {
      setSrc('any')
    }
  }, [phase, src, srcOptions])

  useEffect(() => {
    saveFindingsViewPreferences({
      severity: sev,
      source: src,
      hiddenColumns: hiddenCols ? [...hiddenCols].sort() : null,
    })
  }, [sev, src, hiddenCols])

  const filtered = useMemo(() => {
    const byFacet = rows.filter((f) => {
      if (sev !== 'any' && f.sev.toLowerCase() !== sev) return false
      if (src !== 'any' && f.src !== src) return false
      return true
    })
    // allColumns, not the visibility-filtered columns: search and sort must
    // still work on a field whose column the user hid (e.g. the active Time
    // sort key). The helpers only touch the column matching the query/sort key.
    return searchRows(byFacet, allColumns, query)
  }, [rows, query, sev, src, allColumns])

  const sorted = useMemo(() => sortRows(filtered, allColumns, sort), [filtered, allColumns, sort])

  const exportFindings = () => {
    try {
      downloadFindingsCsv(sorted)
      notify('ok', `Exported ${sorted.length} finding${sorted.length === 1 ? '' : 's'} as CSV.`)
    } catch (error) {
      notify('err', (error as { message?: string })?.message || 'Failed to export findings.')
    }
  }

  // re-sorting keeps the same rows, so it doesn't reset the page
  useEffect(() => { setPage(1) }, [query, sev, src, pageSize, exView])

  const pageCount = Math.max(1, Math.ceil(sorted.length / pageSize))
  const safePage = Math.min(page, pageCount)
  const start = (safePage - 1) * pageSize
  const paged = sorted.slice(start, start + pageSize)
  const rangeLabel = sorted.length === 0
    ? '0 of 0'
    : `${start + 1}–${start + paged.length} of ${sorted.length}`

  const refresh = () => {
    reload()
    reloadKpis()
  }

  const kpi = (n: number | undefined) => (kpis ? String(n ?? 0) : NDASH)

  return (
    <>
      <div className="grid grid-cols-4 border-b border-line">
        <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0">
          <span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Total Findings</span>
          <div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1]">{kpi(kpis?.findingsTotal)}</span></div>
          <span className="text-xs text-tx-faint">{kpis ? `${kpis.findingsCritical} critical · ${kpis.findingsHigh} high` : ' '}</span>
        </div>
        <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0">
          <span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Active Cases</span>
          <div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1]">{kpi(kpis?.casesTotal)}</span></div>
          <span className="text-xs text-tx-faint">{kpis ? `${kpis.casesOpen} open · ${kpis.casesInvestigating} investigating` : ' '}</span>
        </div>
        <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0">
          <span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Critical Alerts</span>
          <div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1] text-crit">{kpi(kpis?.findingsCritical)}</span></div>
          <span className="text-xs text-tx-faint">requires immediate attention</span>
        </div>
        <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0">
          <span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">High Priority</span>
          <div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1] text-high">{kpi(kpis?.findingsHigh)}</span></div>
          <span className="text-xs text-tx-faint">review within 24h</span>
        </div>
      </div>

      <div className="flex items-center gap-3 flex-wrap px-[22px] py-[13px] border-b border-line">
        <div className="search" style={{ maxWidth: 300 }}>
          <span><Icon name="search" /></span>
          <input aria-label="Search findings" placeholder="Search findings, hosts, techniques…" value={query} onChange={(e) => setQuery(e.target.value)} />
        </div>
        <FilterButton
          activeCount={(sev !== 'any' ? 1 : 0) + (src !== 'any' ? 1 : 0) + (exView !== 'hide' ? 1 : 0)}
          onClearAll={() => { setSev('any'); setSrc('any'); setExView('hide'); setHiddenCols(null) }}
        >
          <FilterGroup
            label="Severity"
            value={sev}
            onSelect={(value) => {
              if (isFindingsSeverityFilter(value)) setSev(value)
            }}
            options={[
              { value: 'any', label: 'Any' },
              { value: 'critical', label: 'Critical' },
              { value: 'high', label: 'High' },
              { value: 'medium', label: 'Medium' },
              { value: 'low', label: 'Low' },
            ]}
          />
          <FilterGroup label="Source" value={src} onSelect={setSrc} options={srcOptions} />
          <FilterGroup
            label="Excluded IPs"
            value={exView}
            onSelect={(value) => {
              if (isExclusionView(value)) setExView(value)
            }}
            options={EXCLUSION_VIEWS}
          />
          <ColumnPicker
            columns={allColumns}
            hidden={effectiveHidden}
            onToggle={(key) => setHiddenCols((h) => {
              const next = new Set(h ?? defaultHidden)
              if (next.has(key)) next.delete(key)
              else next.add(key)
              return next
            })}
          />
        </FilterButton>
        <div className="flex-1" />
        <button className="btn ghost icon" title="Refresh" onClick={refresh}><Icon name="refresh" /></button>
        <button
          className="btn primary"
          disabled={sorted.length === 0}
          title="Export filtered findings as CSV"
          onClick={exportFindings}
        ><Icon name="download" /> Export</button>
      </div>

      {exView !== 'hide' && (
        <div className="exclusions-banner" role="status">
          <Icon name="eye" size={14} />
          {exView === 'only'
            ? 'Showing only findings that name an excluded IP. They stay out of the queue and KPIs.'
            : 'Showing excluded findings alongside the queue. Rows marked “excluded” name an excluded IP.'}
          <button className="btn ghost" onClick={() => setExView('hide')}>Hide them</button>
        </div>
      )}
      <div className="table-wrap list-scroll list-scroll-kpi">
        <DataTable
          columns={columns}
          rows={paged}
          rowKey={(f) => f.id}
          phase={phase}
          error={error}
          sort={sort}
          onSort={toggleSort}
          onRowClick={(f) => setDetailId(f.id)}
          onRetry={refresh}
          className="tbl findings-tbl"
          loadingMessage={<EmptyState loading table compact icon="search" title="Loading findings…" />}
          emptyMessage={
            exView === 'only' && rows.length === 0 ? (
              <EmptyState
                table
                icon="filter"
                title="No findings name an excluded IP"
                body="Nothing is being hidden from the queue right now."
                primary={{ label: 'Back to the queue', onClick: () => setExView('hide'), icon: 'close' }}
              />
            ) : (
            <EmptyState
              table
              icon={rows.length === 0 ? 'shield' : 'filter'}
              title={rows.length === 0 ? 'No findings yet' : 'No findings match this view'}
              body={rows.length === 0 ? 'Ingest alerts or run a workflow to populate the findings queue.' : 'Clear search and filters to return to the full findings queue.'}
              primary={rows.length === 0 ? { label: 'Configure integrations', onClick: () => goSettings('integrations'), icon: 'link' } : { label: 'Clear filters', onClick: () => { setQuery(''); setSev('any'); setSrc('any') }, icon: 'close' }}
            />
            )
          }
        />
      </div>
      <div className="pager">
        <span style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
          Rows per page:
          <select
            className="pg-size"
            aria-label="Rows per page"
            value={pageSize}
            onChange={(e) => setPageSize(Number(e.target.value))}
          >
            {[10, 25, 50, 100].map((n) => <option key={n} value={n}>{n}</option>)}
          </select>
        </span>
        <span>{rangeLabel}</span>
        <span style={{ display: 'flex', gap: 6 }}>
          <button
            className="pg-btn"
            disabled={safePage <= 1}
            onClick={() => setPage((p) => Math.max(1, p - 1))}
            title="Previous page"
          ><Icon name="chevL" size={14} /></button>
          <button
            className="pg-btn"
            disabled={safePage >= pageCount}
            onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
            title="Next page"
          ><Icon name="chevR" size={14} /></button>
        </span>
      </div>
      <ExclusionsSection
        refreshKey={exclusionsKey}
        onChanged={refresh}
        onShowExcluded={() => setExView('only')}
      />
      <FindingPopup
        id={detailId}
        onClose={() => setDetailId(null)}
        onChanged={() => { reload(); reloadKpis(); setExclusionsKey((k) => k + 1) }}
        onConfigureAi={() => goSettings('ai-config')}
      />
    </>
  )
}

function sevB(n: number, cls: string) {
  return n ? <span className={`scount ${cls}`}>{n}</span> : <span className="scount zero">·</span>
}

function verdictLabel(verdict: LayerVerdict): string {
  switch (verdict) {
    case 'rule':
      return 'rule'
    case 'loglm':
      return 'LogLM'
    case 'both':
      return 'both'
    case 'missed':
      return 'missed'
    default: {
      const _exhaustive: never = verdict
      return _exhaustive
    }
  }
}

function AttackTab() {
  const [range, setRange] = useState('All')
  const [conf, setConf] = useState(0)
  const [runDraft, setRunDraft] = useState('')
  const [runId, setRunId] = useState('')
  const [expanded, setExpanded] = useState<string | null>(null)
  const { data, phase, error, reload } = useAttack(conf, range, runId)
  const toggle = (id: string) => setExpanded((cur) => (cur === id ? null : id))
  const applyRun = () => {
    setExpanded(null)
    setRunId(runDraft.trim())
  }

  const techniques = data?.techniques ?? []
  const coverage = Boolean(data?.coverage && runId)
  const k = data?.kpis ?? { techniques: 0, detections: 0, critical: 0, high: 0 }
  const caught = techniques.filter((t) => t.verdict && t.verdict !== 'missed').length
  const missed = techniques.filter((t) => t.verdict === 'missed').length
  const ruleLayer = techniques.filter((t) => t.verdict === 'rule' || t.verdict === 'both').length
  const tacticDist = data?.tacticDist ?? []
  const maxTac = Math.max(1, ...tacticDist.map((t) => t[1]))
  const tac = tacticDist.slice(0, 6).map((t) => ({ label: t[0], val: t[1], pct: Math.round((t[1] / maxTac) * 100) }))
  const sevList = data?.sevDist ?? []
  const sevTotal = sevList.reduce((a, s) => a + s[1], 0)
  const sevSegs = sevList.map((s) => ({ v: sevTotal ? s[1] / sevTotal : 0, color: s[2] }))
  const cols = coverage ? 6 : 9

  return (
    <>
      <div className="grid grid-cols-4 border-b border-line">
        {coverage ? (
          <>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Techniques</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1]">{k.techniques}</span></div><span className="text-xs text-tx-faint">in this run</span></div>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Caught</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1]">{caught}</span></div><span className="text-xs text-tx-faint">not missed</span></div>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Missed</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1] text-crit">{missed}</span></div><span className="text-xs text-tx-faint">no correlated finding</span></div>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Rule layer</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1]">{ruleLayer}</span></div><span className="text-xs text-tx-faint">rule or both</span></div>
          </>
        ) : (
          <>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Unique Techniques</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1]">{k.techniques}</span></div><span className="text-xs text-tx-faint">observed across findings</span></div>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Total Detections</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1]">{k.detections}</span></div><span className="text-xs text-tx-faint">mapped to ATT&CK</span></div>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">Critical Severity</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1] text-crit">{k.critical}</span></div><span className="text-xs text-tx-faint">detections by severity</span></div>
            <div className="relative flex flex-col gap-[3px] px-[22px] py-4 border-r border-line-soft last:border-r-0"><span className="text-[11px] font-semibold tracking-[0.07em] uppercase text-tx-3 truncate">High Severity</span><div className="flex items-baseline gap-2.5"><span className="text-[30px] font-semibold tracking-[-0.02em] leading-[1.1] text-high">{k.high}</span></div><span className="text-xs text-tx-faint">detections by severity</span></div>
          </>
        )}
      </div>

      <div className="flex items-center gap-3 flex-wrap px-[22px] py-[13px] border-b border-line">
        <span className="bar-cap">Run</span>
        <input
          className="field-input coverage-run-input"
          value={runDraft}
          placeholder="run id (optional)"
          aria-label="Coverage run id"
          onChange={(e) => setRunDraft(e.target.value)}
          onKeyDown={(e) => { if (e.key === 'Enter') applyRun() }}
        />
        <button className="btn ghost" onClick={applyRun}>Show coverage</button>
        {runId && (
          <button className="btn ghost" onClick={() => { setRunDraft(''); setRunId(''); setExpanded(null) }}>Clear</button>
        )}
        <div className="flex-1" />
        {!coverage && (
          <>
            <span className="bar-cap">Time range</span>
            <div className="range-tabs">
              {['24h', '7d', '30d', 'All'].map((r) => (
                <button key={r} className={range === r ? 'active' : ''} onClick={() => setRange(r)}>{r}</button>
              ))}
            </div>
            <div className="conf-ctrl">
              <span className="bar-cap">Min confidence</span>
              <input type="range" min={0} max={0.99} step={0.01} value={conf} className="conf-range" aria-label="Minimum confidence threshold" onChange={(e) => setConf(parseFloat(e.target.value))} />
              <span className="mono" style={{ color: 'var(--tx-2)', fontSize: '12.5px' }}>{conf.toFixed(2)}</span>
            </div>
          </>
        )}
        <button className="btn ghost icon" title="Refresh" onClick={reload}><Icon name="refresh" /></button>
      </div>

      {!coverage && (
      <div className="flex gap-4 items-stretch px-[22px] pt-5 pb-4">
        <div className="bg-panel border border-line rounded-lg shadow-panel overflow-hidden flex-[1.4] min-w-0 flex flex-col">
          <div className="flex items-center gap-2.5 px-[18px] py-[15px] border-b border-line-soft"><h3 className="text-[14.5px]">Tactics distribution</h3></div>
          <div className="p-[18px] overflow-x-hidden flex-1"><Hbars items={tac} /></div>
        </div>
        <div className="bg-panel border border-line rounded-lg shadow-panel overflow-hidden flex-1 min-w-[300px] flex flex-col">
          <div className="flex items-center gap-2.5 px-[18px] py-[15px] border-b border-line-soft"><h3 className="text-[14.5px]">Severity split</h3></div>
          <div className="p-[18px] overflow-x-hidden flex-1 flex items-center justify-center gap-6 flex-wrap">
            <Pie segs={sevSegs} size={220} />
            <div className="legend">
              {sevList.map((s) => (
                <div className="li" key={s[0]}><span className="sw" style={{ background: s[2] }} />{s[0]}<span className="v">{s[1]}</span></div>
              ))}
              <div className="li li-total"><span className="sw" style={{ background: 'transparent' }} />Total<span className="v">{sevTotal}</span></div>
            </div>
          </div>
        </div>
      </div>
      )}

      <div className="px-[22px] pb-6" style={coverage ? { paddingTop: 20 } : undefined}>
        <div className="bg-panel border border-line rounded-lg shadow-panel overflow-hidden">
          <div className="flex items-center gap-2.5 px-[18px] py-[15px] border-b border-line-soft">
            <h3 className="text-[14.5px]">{coverage ? 'Techniques by layer' : 'Techniques by occurrence'}</h3>
            <span className="flex-1" />
            <span className="text-xs text-tx-3">
              {coverage
                ? `${techniques.length} techniques · click a row for missed-step evidence`
                : `${techniques.length} techniques · click a row for findings`}
            </span>
          </div>
          <div className="table-wrap list-scroll list-scroll-attack">
            <table className="tbl attack-tbl">
              <thead>
                <tr>
                  {coverage ? (
                    <><th>ID</th><th>Name</th><th>Tactic</th><th>Verdict</th><th>Missed</th><th /></>
                  ) : (
                    <><th>ID</th><th>Name</th><th>Tactic</th>
                    <th>Total</th><th>Critical</th><th>High</th><th>Medium</th><th>Low</th><th /></>
                  )}
                </tr>
              </thead>
              <tbody>
                {phase === 'loading' && (
                  <tr><td colSpan={cols}><EmptyState loading table compact icon="graph" title="Loading techniques…" /></td></tr>
                )}
                {phase === 'error' && (
                  <tr><td colSpan={cols}><EmptyState error table icon="alert" title="Couldn’t load ATT&CK data" body={error} primary={{ label: 'Retry', onClick: reload, icon: 'refresh' }} /></td></tr>
                )}
                {phase === 'ready' && data?.runError && (
                  <tr><td colSpan={cols}><EmptyState table icon="alert" title="Couldn’t read that run" body={data.runError} /></td></tr>
                )}
                {phase === 'ready' && !data?.runError && techniques.length === 0 && (
                  <tr><td colSpan={cols}><EmptyState table icon="filter" title={coverage ? 'No techniques on this run' : 'No techniques at this confidence threshold'} body={coverage ? 'The run has no action-trace steps with a technique id.' : 'Lower the confidence threshold or load findings with ATT&CK mappings.'} /></td></tr>
                )}
                {phase === 'ready' && !data?.runError && techniques.map((t) => (
                  <Fragment key={t.id}>
                    <tr className={`clickable${expanded === t.id ? ' expanded' : ''}`} onClick={() => toggle(t.id)}>
                      <td><span className="id-cell">{t.id}</span></td>
                      <td>{t.name}</td>
                      <td><span className="tactic-chip">{t.tactic}</span></td>
                      {coverage ? (
                        <>
                          <td>{t.verdict ? <span className={`coverage-verdict ${t.verdict}`}>{verdictLabel(t.verdict)}</span> : '—'}</td>
                          <td><span className="tot-badge">{t.missed?.length ?? 0}</span></td>
                        </>
                      ) : (
                        <>
                          <td><span className="tot-badge">{t.total}</span></td>
                          <td>{sevB(t.c, 'c')}</td><td>{sevB(t.h, 'h')}</td><td>{sevB(t.m, 'm')}</td><td>{sevB(t.l, 'l')}</td>
                        </>
                      )}
                      <td>
                        <span className="row-act">
                          <button title={expanded === t.id ? (coverage ? 'Hide coverage' : 'Hide findings') : (coverage ? 'Show missed steps' : 'Show findings')} onClick={(e) => { e.stopPropagation(); toggle(t.id) }}>
                            <span className="caret" style={{ transform: expanded === t.id ? 'rotate(180deg)' : undefined }}><Icon name="chevD" size={14} /></span>
                          </button>
                        </span>
                      </td>
                    </tr>
                    {expanded === t.id && (
                      <tr className="tech-expand"><td colSpan={cols}><AttackTechniqueFindings techniqueId={t.id} coverage={coverage ? t : undefined} /></td></tr>
                    )}
                  </Fragment>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  )
}

const DAY = 86400000

interface TLBar {
  e: TimelineEvent
  left: number
  w: number
  top: number
  label: string
}
interface TLLayout {
  min: number
  max: number
  pxPerDay: number
  innerW: number
  plotH: number
  bars: TLBar[]
  ticks: { px: number; lab: string }[]
  grids: { px: number; h: number }[]
  months: { px: number; lab: string }[]
}

function computeLayout(events: TimelineEvent[], zoom: number, containerW: number): TLLayout {
  if (events.length === 0) {
    return { min: 0, max: 1, pxPerDay: 1, innerW: containerW || 800, plotH: 200, bars: [], ticks: [], grids: [], months: [] }
  }
  const times = events.map((e) => e.t)
  const min = Math.min(...times) - DAY * 0.6
  const max = Math.max(...times) + DAY * 0.6
  const spanDays = (max - min) / DAY
  const cw = containerW || 800
  const pxPerDay = ((cw - 32) / spanDays) * zoom
  const x = (t: number) => ((t - min) / DAY) * pxPerDay + 16
  const innerW = spanDays * pxPerDay + 32

  const laneEnds: number[] = []
  const rowH = 22
  const gap = 8
  const topPad = 54
  const botPad = 28
  const bars: TLBar[] = events.map((e) => {
    const label = `${e.sev.toUpperCase()} · ${e.id}`
    const w = Math.max(150, label.length * 6.5 + 26)
    const left = x(e.t)
    let lane = 0
    while (laneEnds[lane] !== undefined && laneEnds[lane] > left - 8) lane++
    laneEnds[lane] = left + w
    return { e, left, w, lane: lane, label, top: 54 + lane * (rowH + gap) }
  })
  const laneCount = Math.max(laneEnds.length, 1)
  const plotH = topPad + laneCount * (rowH + gap) + botPad

  const stepDays = Math.max(1, Math.ceil(64 / pxPerDay))
  const ticks: { px: number; lab: string }[] = []
  const grids: { px: number; h: number }[] = []
  const d0 = new Date(min)
  d0.setHours(0, 0, 0, 0)
  let t0 = d0.getTime()
  if (t0 < min) t0 += DAY
  const gridH = plotH - 52 - botPad + 14
  for (let t = t0; t <= max; t += DAY * stepDays) {
    const px = x(t)
    const d = new Date(t)
    const lab = `${d.getMonth() + 1}/${d.getDate()}`
    ticks.push({ px, lab })
    grids.push({ px, h: gridH })
  }
  const months: { px: number; lab: string }[] = []
  const mi = new Date(min)
  mi.setDate(1)
  mi.setHours(0, 0, 0, 0)
  for (let mt = mi.getTime(); mt <= max; ) {
    const d = new Date(mt)
    const px = Math.max(x(mt), 14)
    months.push({ px, lab: `${TL_MONTHS[d.getMonth()]} ${d.getFullYear()}` })
    d.setMonth(d.getMonth() + 1)
    mt = d.getTime()
  }
  return { min, max, pxPerDay, innerW, plotH, bars, ticks, grids, months }
}

function TimelineTab() {
  const [filter, setFilter] = useState<'all' | 'finding'>('all')
  const [speed, setSpeed] = useState(1)
  const [zoom, setZoom] = useState(1)
  const [playing, setPlaying] = useState(false)
  const [containerW, setContainerW] = useState(800)
  const [detailId, setDetailId] = useState<string | null>(null)

  const scrollRef = useRef<HTMLDivElement>(null)
  const innerRef = useRef<HTMLDivElement>(null)
  const playheadRef = useRef<HTMLDivElement>(null)
  const rafRef = useRef<number | null>(null)
  const lastRef = useRef(0)
  const playTRef = useRef(0)
  const engagedRef = useRef(false)
  const playingRef = useRef(false)
  const speedRef = useRef(1)
  const downRef = useRef(false)

  const { events: tlEvents, phase: tlPhase } = useTimeline()
  const events = useMemo(() => tlEvents.filter((e) => filter === 'all' || e.kind === 'finding'), [tlEvents, filter])
  const layout = useMemo(() => computeLayout(events, zoom, containerW), [events, zoom, containerW])
  const layoutRef = useRef(layout)
  layoutRef.current = layout

  const positionPlayhead = useCallback(() => {
    const inner = innerRef.current
    const ph = playheadRef.current
    const scroll = scrollRef.current
    const lo = layoutRef.current
    if (!inner || !ph) return
    const px = ((playTRef.current - lo.min) / DAY) * lo.pxPerDay + 16
    ph.style.left = px + 'px'
    ph.style.height = lo.plotH - 44 + 'px'
    ph.style.display = engagedRef.current ? 'block' : 'none'
    inner.classList.toggle('engaged', engagedRef.current)
    if (engagedRef.current) {
      inner.querySelectorAll<HTMLElement>('.tl-bar').forEach((el) => {
        el.classList.toggle('fut', Number(el.dataset.t) > playTRef.current)
      })
    } else {
      inner.querySelectorAll<HTMLElement>('.tl-bar.fut').forEach((el) => el.classList.remove('fut'))
    }
    if (playingRef.current && scroll) {
      const target = px - scroll.clientWidth * 0.5
      scroll.scrollLeft = Math.max(0, Math.min(lo.innerW - scroll.clientWidth, target))
    }
  }, [])

  useLayoutEffect(() => {
    const el = scrollRef.current
    if (!el) return
    setContainerW(el.clientWidth || 800)
    const ro = new ResizeObserver(() => setContainerW(el.clientWidth || 800))
    ro.observe(el)
    return () => ro.disconnect()
  }, [])

  useEffect(() => {
    if (!engagedRef.current) playTRef.current = layout.min
    positionPlayhead()
  }, [layout, positionPlayhead])

  useEffect(() => () => { if (rafRef.current) cancelAnimationFrame(rafRef.current) }, [])

  const pause = useCallback(() => {
    playingRef.current = false
    setPlaying(false)
    if (rafRef.current) cancelAnimationFrame(rafRef.current)
    rafRef.current = null
  }, [])

  const step = useCallback((ts: number) => {
    if (!playingRef.current) return
    const lo = layoutRef.current
    const dt = (ts - lastRef.current) / 1000
    lastRef.current = ts
    playTRef.current += 4 * speedRef.current * DAY * dt
    if (playTRef.current >= lo.max) {
      playTRef.current = lo.max
      positionPlayhead()
      pause()
      return
    }
    positionPlayhead()
    rafRef.current = requestAnimationFrame(step)
  }, [positionPlayhead, pause])

  const play = useCallback(() => {
    if (playTRef.current >= layoutRef.current.max - 1) playTRef.current = layoutRef.current.min
    engagedRef.current = true
    // honour the OS reduced-motion preference: snap to the end instead of
    // animating the scrub through every frame
    if (window.matchMedia?.('(prefers-reduced-motion: reduce)').matches) {
      playTRef.current = layoutRef.current.max
      positionPlayhead()
      return
    }
    playingRef.current = true
    setPlaying(true)
    lastRef.current = performance.now()
    rafRef.current = requestAnimationFrame(step)
  }, [step, positionPlayhead])

  const togglePlay = () => (playingRef.current ? pause() : play())

  const setFromX = (clientX: number) => {
    const inner = innerRef.current
    const lo = layoutRef.current
    if (!inner) return
    const r = inner.getBoundingClientRect()
    const px = clientX - r.left
    let t = lo.min + ((px - 16) / lo.pxPerDay) * DAY
    t = Math.max(lo.min, Math.min(lo.max, t))
    playTRef.current = t
    engagedRef.current = true
    positionPlayhead()
  }

  const changeFilter = (f: 'all' | 'finding') => {
    pause()
    engagedRef.current = false
    setFilter(f)
  }
  const setZoomF = (f: number) => setZoom((z) => Math.max(1, Math.min(12, z * f)))
  const fit = () => {
    pause()
    engagedRef.current = false
    playTRef.current = layoutRef.current.min
    setZoom(1)
    positionPlayhead()
  }
  const exportCsv = () => {
    const rows = [
      ['id', 'severity', 'technique', 'kind', 'timestamp'],
      ...events.map((e) => [e.id, e.sev, e.tech, e.kind, new Date(e.t).toISOString()]),
    ]
    const csv = rows.map((r) => r.join(',')).join('\n')
    const blob = new Blob([csv], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'timeline-events.csv'
    a.click()
    setTimeout(() => URL.revokeObjectURL(a.href), 1000)
  }

  return (
    <>
      <div className="tl-controls">
        <div className="tl-toggle">
          <button className={filter === 'all' ? 'active' : ''} onClick={() => changeFilter('all')}>All</button>
          <button className={filter === 'finding' ? 'active' : ''} onClick={() => changeFilter('finding')}>finding</button>
        </div>
        <span className="tl-count">{tlPhase === 'loading' ? 'Loading…' : `${events.length} events`}</span>
        <div className="grow" />
        <button className="tl-iconbtn" title="Zoom in" onClick={() => setZoomF(1.5)}><Icon name="zoomIn" /></button>
        <button className="tl-iconbtn" title="Zoom out" onClick={() => setZoomF(1 / 1.5)}><Icon name="zoomOut" /></button>
        <button className="tl-iconbtn" title="Fit all events" onClick={fit}><Icon name="fit" /></button>
        <button className={`tl-iconbtn play${playing ? ' on' : ''}`} title="Play / pause" onClick={togglePlay}>
          <Icon name={playing ? 'pause' : 'play'} />
        </button>
        <div className="tl-seg">
          {[1, 2, 4].map((s) => (
            <button key={s} className={speed === s ? 'active' : ''} onClick={() => { setSpeed(s); speedRef.current = s }}>{s}×</button>
          ))}
        </div>
        <button className="tl-iconbtn" title="Export visible events (CSV)" onClick={exportCsv}><Icon name="download" /></button>
      </div>
      <div className="tl-hint">Drag anywhere to scrub · click a bar to investigate · scroll to pan</div>
      {tlPhase === 'ready' && events.length === 0 && (
        <EmptyState
          icon="clock"
          title={filter === 'finding' ? 'No finding events in this window' : 'No timeline events yet'}
          body={filter === 'finding' ? 'Switch to All events or load findings with timestamps.' : 'Create cases or ingest findings to build an investigation timeline.'}
          primary={filter === 'finding' ? { label: 'Show all events', onClick: () => changeFilter('all'), icon: 'filter' } : undefined}
        />
      )}
      <div className="tl-scroll" ref={scrollRef}>
        <div
          className="tl-inner"
          ref={innerRef}
          style={{ width: layout.innerW, height: layout.plotH }}
          onPointerDown={(e) => {
            if ((e.target as HTMLElement).closest('.tl-bar')) return
            downRef.current = true
            pause()
            setFromX(e.clientX)
            try { innerRef.current?.setPointerCapture(e.pointerId) } catch { /* noop */ }
          }}
          onPointerMove={(e) => { if (downRef.current) setFromX(e.clientX) }}
          onPointerUp={() => { downRef.current = false }}
        >
          {layout.grids.map((g, i) => (
            <div key={`g${i}`} className="tl-grid" style={{ left: g.px, height: g.h }} />
          ))}
          <div className="tl-axis-line" />
          {layout.months.map((m, i) => (
            <div key={`m${i}`} className="tl-month" style={{ left: m.px }}>{m.lab}</div>
          ))}
          {layout.ticks.map((t, i) => (
            <Fragment key={`t${i}`}>
              <div className="tl-tlabel" style={{ left: t.px }}>{t.lab}</div>
              <div className="tl-tlabel bottom" style={{ left: t.px }}>{t.lab}</div>
            </Fragment>
          ))}
          {layout.bars.map((b, i) => (
            <div
              key={i}
              className="tl-bar"
              data-t={b.e.t}
              style={{ left: b.left, top: b.top, width: b.w }}
              title={`${b.e.id} · ${b.e.kind}`}
              onClick={(ev) => { ev.stopPropagation(); if (b.e.kind === 'finding') setDetailId(b.e.id) }}
            >
              <i style={{ background: SEV_COLOR[b.e.sev] }} />
              <span>{b.label}</span>
            </div>
          ))}
          <div className="tl-playhead" ref={playheadRef} style={{ display: 'none' }} />
        </div>
      </div>
      <FindingPopup id={detailId} onClose={() => setDetailId(null)} />
    </>
  )
}
