import {
  useEffect,
  useMemo,
  useRef,
  useState,
  type KeyboardEvent,
  type PointerEvent as ReactPointerEvent,
} from 'react'
import { format } from 'date-fns'
import { Markdown } from '../shared/Markdown'
import { Icon } from '../shared/icons'
import { Cost, PROVENANCE_LABEL } from '../shared/cost'
import {
  agentsApi,
  aiConfigApi,
  analyticsApi,
  claudeApi,
  conversationsApi,
  mcpApi,
  reasoningApi,
  streamFetch,
  type CostEstimate,
  type ConversationDetail,
  type ImportConversationInput,
} from '../services/api'
import { notificationService } from '../services/notifications'
import { useConversations } from './useConversations'
import { Popup, Select } from '../shared/ui'

interface ChatAgent {
  id: string
  name: string
  specialization?: string
  description?: string
  icon?: string
  color?: string
}
type Role = 'user' | 'vigil' | 'error'
interface ChatMsg {
  role: Role
  text: string
  ms?: number
}

interface SessionSummary {
  total_interactions: number
  total_cost_usd: number | null
  unpriced_calls: number
  total_input_tokens: number
  total_output_tokens: number
}

function sessionSummaryFrom(s: Partial<SessionSummary>): SessionSummary {
  return {
    total_interactions: s.total_interactions ?? 0,
    total_cost_usd: s.total_cost_usd ?? null,
    unpriced_calls: s.unpriced_calls ?? 0,
    total_input_tokens: s.total_input_tokens ?? 0,
    total_output_tokens: s.total_output_tokens ?? 0,
  }
}
interface TraceItem {
  interaction_id: string
  created_at?: string
  has_thinking?: boolean
  has_tools?: boolean
  agent_id?: string
  input_tokens?: number
  output_tokens?: number
  cost_usd?: number
}
interface TraceDetail {
  interaction_id: string
  model?: string
  stop_reason?: string
  duration_ms?: number
  cost_usd?: number
  thinking_content?: string
  response_content?: string
  tool_calls?: Array<{ name?: string; input?: unknown }>
  tool_results?: Array<{ tool_use_id?: string; content?: unknown; is_error?: boolean }>
}

const MODEL = 'claude-sonnet-4-6'
const CONTEXT_WINDOW = 200000
// shown only until the live model list arrives from GET /claude/models
const MODEL_FALLBACK = [{ id: MODEL, name: 'Claude Sonnet 4.6' }]
const newSessionId = () =>
  typeof crypto !== 'undefined' && 'randomUUID' in crypto
    ? crypto.randomUUID()
    : `sess-${Date.now()}-${Math.floor(Math.random() * 1e6)}`

interface Conversation {
  id: string
  title: string
  ts: number
  messages: ChatMsg[]
  /** the seed prompt, when opened from an "Investigate with Vigil" affordance;
   *  re-opening the same finding restores the thread instead of duplicating it */
  key?: string
}
const HISTORY_KEY = 'soc.chat.history'
const HISTORY_MAX = 30
function loadHistory(): Conversation[] {
  try {
    const raw = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]')
    return Array.isArray(raw) ? raw : []
  } catch {
    return []
  }
}
function saveHistory(list: Conversation[]) {
  try {
    localStorage.setItem(HISTORY_KEY, JSON.stringify(list.slice(0, HISTORY_MAX)))
  } catch {
    /* empty */
  }
}

/* Investigation dedup: key (seed prompt) → conversation/session id. The server
   conversation store has no "key" column, so this small localStorage map
   preserves the "reopen the same finding's thread" behavior. */
const KEYMAP_KEY = 'soc.chat.keymap'
function loadKeymap(): Record<string, string> {
  try {
    const m = JSON.parse(localStorage.getItem(KEYMAP_KEY) || '{}')
    return m && typeof m === 'object' ? (m as Record<string, string>) : {}
  } catch {
    return {}
  }
}
function setKeymapEntry(key: string, sid: string) {
  try {
    const m = loadKeymap()
    m[key] = sid
    localStorage.setItem(KEYMAP_KEY, JSON.stringify(m))
  } catch {
    /* ignore */
  }
}

const IMPORT_MARKER_KEY = 'soc.chat.imported'

interface HistRow {
  id: string
  title: string
  count: number
  ts: number | null
  archived?: boolean
}
function histTime(ts: number | null): string {
  if (ts == null) return ''
  const d = new Date(ts)
  return isNaN(d.getTime()) ? '' : format(d, 'MMM d, HH:mm')
}
/* user + assistant turns only */
function toChatMsgs(msgs: ConversationDetail['messages']): ChatMsg[] {
  return msgs
    .filter((m) => m.role === 'user' || m.role === 'assistant')
    .map((m) =>
      m.role === 'user'
        ? { role: 'user' as Role, text: m.content }
        : { role: 'vigil' as Role, text: m.content || '_(no response)_' },
    )
}

interface ChatSettings {
  model: string
  maxTokens: number
  systemPrompt: string
}
const SETTINGS_KEY = 'soc.chat.settings'
const DEFAULT_SETTINGS: ChatSettings = { model: MODEL, maxTokens: 4096, systemPrompt: '' }
function loadSettings(): ChatSettings {
  try {
    return { ...DEFAULT_SETTINGS, ...JSON.parse(localStorage.getItem(SETTINGS_KEY) || '{}') }
  } catch {
    return DEFAULT_SETTINGS
  }
}

function traceTime(s?: string): string {
  if (!s) return '—'
  const d = new Date(s)
  return isNaN(d.getTime()) ? '—' : format(d, 'HH:mm:ss')
}
/* without throwing on cycles */
function safeJson(v: unknown): string {
  if (v == null) return ''
  if (typeof v === 'string') return v
  try {
    return JSON.stringify(v, null, 2)
  } catch {
    return String(v)
  }
}

function VigilMessage({ text }: { text: string; ms?: number }) {
  return (
    <div className="msg vigil">
      <div className="body"><Markdown>{text}</Markdown></div>
      <div className="msg-actions">
        <button title="Copy" onClick={() => navigator.clipboard?.writeText(text)}><Icon name="copy" size={15} /></button>
        <button title="More"><Icon name="more" size={15} /></button>
      </div>
    </div>
  )
}

export default function Chat({
  open,
  onClose,
  seed,
  width = 420,
  minWidth = 360,
  maxWidth = 720,
  onWidthChange,
  onWidthCommit,
  onResizeStateChange,
  onSeedConsumed,
}: {
  open: boolean
  onClose: () => void
  seed?: string | null
  width?: number
  minWidth?: number
  maxWidth?: number
  onWidthChange?: (width: number) => void
  onWidthCommit?: (width: number) => void
  onResizeStateChange?: (resizing: boolean) => void
  onSeedConsumed?: () => void
}) {
  const [messages, setMessages] = useState<ChatMsg[]>([])
  const [draft, setDraft] = useState('')
  const [loading, setLoading] = useState(false)
  const [streamText, setStreamText] = useState('')
  // true between a `tool_processing` event and the next `text` chunk
  const [isProcessingTools, setIsProcessingTools] = useState(false)
  const [agents, setAgents] = useState<ChatAgent[]>([])
  const [agentId, setAgentId] = useState('')
  const [menuOpen, setMenuOpen] = useState(false)
  const [agentsInfoOpen, setAgentsInfoOpen] = useState(false)
  const [historyOpen, setHistoryOpen] = useState(false)
  const [settingsOpen, setSettingsOpen] = useState(false)
  const [resizing, setResizing] = useState(false)
  // the server is the source of truth; this shows when it can't be reached
  const [history, setHistory] = useState<Conversation[]>(() => loadHistory())
  const [showArchived, setShowArchived] = useState(false)
  const {
    items: serverConvos,
    phase: histPhase,
    reload: reloadHistory,
  } = useConversations(showArchived)
  const [renamingId, setRenamingId] = useState<string | null>(null)
  const [renameDraft, setRenameDraft] = useState('')
  const [savedSettings] = useState(loadSettings)
  const [model, setModel] = useState(savedSettings.model)
  const [maxTokens, setMaxTokens] = useState(savedSettings.maxTokens)
  const [systemPrompt, setSystemPrompt] = useState(savedSettings.systemPrompt)
  const [models, setModels] = useState<{ id: string; name: string }[]>([])
  // read by the stale-model self-heal below
  const [configuredDefault, setConfiguredDefault] = useState<string | null>(null)
  const [configSettled, setConfigSettled] = useState(false)
  const [mcpStatus, setMcpStatus] = useState<{ available: number; total: number } | null>(null)
  // null until the first debounced estimate lands
  const [costEstimate, setCostEstimate] = useState<CostEstimate | null>(null)
  const [exactTokens, setExactTokens] = useState<number | null>(null)
  const [traceOpen, setTraceOpen] = useState(false)
  const [traceLoading, setTraceLoading] = useState(false)
  const [traceItems, setTraceItems] = useState<TraceItem[]>([])
  const [traceSelected, setTraceSelected] = useState<TraceDetail | null>(null)
  const [sessionSummary, setSessionSummary] = useState<SessionSummary | null>(null)

  const sessionRef = useRef<string>(newSessionId())
  const bodyRef = useRef<HTMLDivElement>(null)
  const taRef = useRef<HTMLTextAreaElement>(null)
  const abortRef = useRef<AbortController | null>(null)
  const menuRef = useRef<HTMLDivElement>(null)
  const openerRef = useRef<HTMLElement | null>(null)
  const panelRef = useRef<HTMLElement>(null)
  const resizeRef = useRef<{
    pointerId: number
    startX: number
    startWidth: number
    lastWidth: number
  } | null>(null)
  const currentKeyRef = useRef<string | null>(null)
  // a saved setting or an in-session pick beats the configured chat_default
  const settingsExistedRef = useRef<boolean>(
    typeof localStorage !== 'undefined' && localStorage.getItem(SETTINGS_KEY) != null,
  )
  const userPickedModelRef = useRef(false)

  useEffect(() => {
    if (open) {
      openerRef.current = document.activeElement as HTMLElement | null
      taRef.current?.focus()
    } else {
      openerRef.current?.focus?.()
      openerRef.current = null
    }
  }, [open])

  useEffect(() => {
    if (open) return
    resizeRef.current = null
    setResizing(false)
    onResizeStateChange?.(false)
  }, [open, onResizeStateChange])

  useEffect(
    () => () => {
      resizeRef.current = null
      onResizeStateChange?.(false)
    },
    [onResizeStateChange],
  )

  // any of the dock's own dialogs (they own their Esc + focus handling)
  const anyPopupOpen = historyOpen || settingsOpen || agentsInfoOpen || traceOpen

  // never while a Popup is open: it handles its own Esc, and closing the dock
  // too would dismiss both at once
  useEffect(() => {
    if (!open) return
    const onKey = (e: globalThis.KeyboardEvent) => {
      if (e.key !== 'Escape' || anyPopupOpen) return
      if (menuOpen) setMenuOpen(false)
      else onClose()
    }
    document.addEventListener('keydown', onKey)
    return () => document.removeEventListener('keydown', onKey)
  }, [open, menuOpen, onClose, anyPopupOpen])

  // unless a Popup is up, which traps focus itself
  const onPanelKeyDown = (e: KeyboardEvent<HTMLElement>) => {
    if (e.key !== 'Tab' || !open || anyPopupOpen) return
    const root = panelRef.current
    if (!root) return
    const f = Array.from(
      root.querySelectorAll<HTMLElement>(
        'button:not([disabled]), textarea, input, a[href], [tabindex]:not([tabindex="-1"])',
      ),
    ).filter((el) => el.offsetParent !== null)
    if (f.length === 0) return
    const first = f[0]
    const last = f[f.length - 1]
    const active = document.activeElement as HTMLElement
    if (e.shiftKey && active === first) {
      e.preventDefault()
      last.focus()
    } else if (!e.shiftKey && active === last) {
      e.preventDefault()
      first.focus()
    }
  }

  useEffect(() => {
    agentsApi
      .listAgents()
      .then((res) => {
        const raw = (res.data?.agents || []) as ChatAgent[]
        const list = raw.map((a) => ({ id: a.id, name: a.name, specialization: a.specialization, description: a.description, icon: a.icon, color: a.color }))
        setAgents(list)
        const corr = list.find((a) => a.id === 'correlator' || /correlat/i.test(a.name))
        if (corr) setAgentId(corr.id)
      })
      .catch(() => {})
  }, [])

  // refetched on every open, so a provider activated later shows up without a
  // full page reload (#409)
  useEffect(() => {
    if (!open) return
    claudeApi
      .getModels()
      .then((r) => setModels((r.data?.models || []) as { id: string; name: string }[]))
      .catch(() => {})
  }, [open])

  // fetched once, the first time the dock opens
  const metaLoadedRef = useRef(false)
  useEffect(() => {
    if (!open || metaLoadedRef.current) return
    metaLoadedRef.current = true
    aiConfigApi
      .getConfig()
      .then((r) => {
        const configured = r.data?.assignments?.chat_default?.model_id
        if (configured) setConfiguredDefault(configured)
        if (configured && !settingsExistedRef.current && !userPickedModelRef.current) {
          setModel(configured)
        }
      })
      .catch(() => {})
      .finally(() => setConfigSettled(true))
    mcpApi
      .getStatuses()
      .then((r) => {
        const statuses = (r.data?.statuses || []) as { status?: string }[]
        const available = statuses.filter((s) => s.status && s.status !== 'error' && s.status !== 'not found').length
        setMcpStatus({ available, total: statuses.length })
      })
      .catch(() => {})
  }, [open])

  // Self-heal a model that is no longer offered (a removed provider, a rename).
  // Without this a stale localStorage model 500s every send until the user
  // re-picks by hand.
  useEffect(() => {
    if (!models.length || !configSettled) return
    if (model && models.some((m) => m.id === model)) return
    const fallback =
      configuredDefault && models.some((m) => m.id === configuredDefault)
        ? configuredDefault
        : models[0].id
    if (fallback && fallback !== model) setModel(fallback)
  }, [models, configSettled, configuredDefault, model])

  useEffect(() => {
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify({ model, maxTokens, systemPrompt }))
    } catch {
      /* empty */
    }
  }, [model, maxTokens, systemPrompt])

  useEffect(() => {
    const el = bodyRef.current
    if (el) el.scrollTop = el.scrollHeight
  }, [messages, streamText, loading])

  useEffect(() => {
    const ta = taRef.current
    if (!ta) return
    ta.style.height = 'auto'
    ta.style.height = Math.min(ta.scrollHeight, 130) + 'px'
  }, [draft])

  useEffect(() => {
    if (!menuOpen) return
    const onDocClick = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false)
    }
    document.addEventListener('mousedown', onDocClick)
    return () => document.removeEventListener('mousedown', onDocClick)
  }, [menuOpen])

  const agentName = agents.find((a) => a.id === agentId)?.name || 'Default agent'

  // debounced + abortable; keeps the previous estimate on failure
  useEffect(() => {
    if (!open) return
    const ctrl = new AbortController()
    const t = setTimeout(() => {
      const payloadMsgs = [
        ...messages
          .filter((m) => m.role !== 'error')
          .map((m) => ({ role: m.role === 'vigil' ? 'assistant' : 'user', content: m.text })),
        ...(draft.trim() ? [{ role: 'user', content: draft }] : []),
      ]
      if (payloadMsgs.length === 0 && !systemPrompt) {
        setCostEstimate(null)
        setExactTokens(null)
        return
      }
      analyticsApi
        .estimateCost({
          provider_type: 'anthropic',
          model_id: model,
          messages: payloadMsgs,
          system_prompt: systemPrompt || undefined,
          max_tokens: maxTokens,
        })
        .then((r) => {
          if (ctrl.signal.aborted) return
          setCostEstimate(r.data)
          setExactTokens(r.data.input_tokens)
        })
        .catch(() => {
          /* keep the previous estimate */
        })
    }, 400)
    return () => {
      clearTimeout(t)
      ctrl.abort()
    }
  }, [open, messages, draft, systemPrompt, model, maxTokens])

  // used only until the first server estimate lands
  const heuristicTokens = useMemo(() => {
    const chars =
      messages.reduce((n, m) => n + m.text.length, 0) +
      streamText.length + systemPrompt.length + draft.length
    return Math.round(chars / 4)
  }, [messages, streamText, systemPrompt, draft])
  const estimatedTokens = exactTokens ?? heuristicTokens
  const ctxPct = Math.min((estimatedTokens / CONTEXT_WINDOW) * 100, 100)
  const ctxState = estimatedTokens > 150000 ? 'danger' : estimatedTokens > 100000 ? 'warn' : 'ok'
  const costTitle = costEstimate
    ? `${
        costEstimate.token_count_method === 'anthropic_count_tokens'
          ? 'Exact token count via Anthropic count_tokens.'
          : costEstimate.token_count_method === 'tiktoken'
            ? 'Token count via tiktoken.'
            : 'Approximate token count (chars ÷ 4).'
      } Pricing: ${PROVENANCE_LABEL[costEstimate.pricing_source]}.`
    : ''

  const send = async (override?: string, opts?: { fresh?: boolean }) => {
    const text = (override ?? draft).trim()
    if (!text || loading) return
    // `fresh` keeps a new investigation's seed off an unrelated conversation
    const base = opts?.fresh ? [] : messages.filter((m) => m.role !== 'error')
    const next: ChatMsg[] = [...base, { role: 'user', text }]
    setMessages(next)
    setDraft('')
    setLoading(true)
    setStreamText('')
    setIsProcessingTools(false)
    const start = Date.now()

    const ac = new AbortController()
    abortRef.current = ac
    try {
      const res = await streamFetch('/claude/chat/stream', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', Accept: 'text/event-stream' },
        body: JSON.stringify({
          messages: next.map((m) => ({ role: m.role === 'vigil' ? 'assistant' : 'user', content: m.text })),
          model,
          max_tokens: maxTokens,
          system_prompt: systemPrompt || undefined,
          agent_id: agentId || undefined,
          session_id: sessionRef.current,
        }),
        signal: ac.signal,
      })
      if (!res.ok) throw new Error(`HTTP ${res.status}`)
      const reader = res.body?.getReader()
      const decoder = new TextDecoder()
      let curText = ''
      let buf = ''
      if (reader) {
        for (;;) {
          const { done, value } = await reader.read()
          if (done) break
          buf += decoder.decode(value, { stream: true })
          const lines = buf.split('\n')
          buf = lines.pop() || ''
          for (const line of lines) {
            if (!line.startsWith('data: ')) continue
            const data = line.slice(6).trim()
            if (!data) continue
            let ev: {
              type?: string
              content?: string
              error?: string
              windowed_messages?: number
              remaining_messages?: number
            }
            try {
              ev = JSON.parse(data)
            } catch {
              continue
            }
            if (ev.error) throw new Error(ev.error)
            if (ev.type === 'tool_processing') {
              // separate tool output from the prose preceding it
              setIsProcessingTools(true)
              if (curText && !curText.endsWith('\n\n')) curText += '\n\n'
            } else if (ev.type === 'context_windowed') {
              curText +=
                `_[Context compressed: ${ev.windowed_messages ?? 0} older ` +
                `messages condensed to stay within the model's limits; recent ` +
                `messages and key details are preserved.]_\n\n`
              setStreamText(curText)
            } else if (ev.type === 'text') {
              setIsProcessingTools(false)
              curText += ev.content || ''
              setStreamText(curText)
            }
          }
        }
      }
      const ms = Date.now() - start
      setMessages((m) => [...m, { role: 'vigil', text: curText || '_(no response)_', ms }])
      // gated inside notificationService by the setting + browser permission
      if (currentKeyRef.current && curText) {
        const summary = curText.replace(/[#*`_>[\]]/g, '').replace(/\s+/g, ' ').trim().slice(0, 140)
        notificationService.notifyInvestigationComplete({
          title: 'Vigil',
          summary: summary || 'Analysis complete',
        })
      }
      // refresh the reasoning-trace summary for this session (best-effort)
      reasoningApi
        .getSessionSummary(sessionRef.current)
        .then((s: Partial<SessionSummary> | null) =>
          setSessionSummary(s ? sessionSummaryFrom(s) : null),
        )
        .catch(() => {})
    } catch (e) {
      const err = e as { name?: string; message?: string }
      if (err?.name !== 'AbortError') {
        setMessages((m) => [...m, { role: 'error', text: `Could not reach Vigil: ${err?.message || e}. Is the backend running?` }])
      }
    } finally {
      setLoading(false)
      setStreamText('')
      setIsProcessingTools(false)
      abortRef.current = null
    }
  }

  const stop = () => abortRef.current?.abort()

  const archiveCurrent = () => {
    if (messages.length === 0) return
    const firstUser = messages.find((m) => m.role === 'user')
    const convo: Conversation = {
      id: sessionRef.current,
      title: (firstUser?.text || 'Conversation').replace(/\s+/g, ' ').trim().slice(0, 70) || 'Conversation',
      ts: Date.now(),
      messages,
      key: currentKeyRef.current || undefined,
    }
    setHistory((h) => {
      const next = [convo, ...h.filter((c) => c.id !== convo.id)].slice(0, HISTORY_MAX)
      saveHistory(next)
      return next
    })
  }

  // the server already persisted every turn, so this only resets local state
  const reset = () => {
    if (loading) return
    archiveCurrent()
    setMessages([])
    sessionRef.current = newSessionId()
    currentKeyRef.current = null
    setSessionSummary(null)
    setCostEstimate(null)
    setExactTokens(null)
    reloadHistory()
  }

  // continues the same session_id, so new turns append to it
  const openConversation = async (id: string, key?: string | null): Promise<boolean> => {
    if (loading) return false
    archiveCurrent()
    setHistoryOpen(false)
    try {
      const res = await conversationsApi.get(id)
      const detail = res.data as ConversationDetail
      setMessages(toChatMsgs(detail.messages || []))
      sessionRef.current = id
      currentKeyRef.current = key ?? null
      setSessionSummary(null)
      setCostEstimate(null)
      setExactTokens(null)
      return true
    } catch {
      const cached = loadHistory().find((c) => c.id === id)
      if (cached) {
        setMessages(cached.messages)
        sessionRef.current = id
        currentKeyRef.current = cached.key || key || null
        setSessionSummary(null)
        return true
      }
      return false
    }
  }

  // the seed prompt is deterministic per finding/case, so it doubles as the
  // dedup key for reusing an existing thread
  const openInvestigation = async (prompt: string) => {
    if (loading) return
    if (currentKeyRef.current === prompt && messages.length > 0) return // already here
    const mapped = loadKeymap()[prompt]
    if (mapped) {
      const opened = await openConversation(mapped, prompt)
      if (opened) return // reopened the existing thread for this finding/case
    }
    archiveCurrent()
    sessionRef.current = newSessionId()
    currentKeyRef.current = prompt
    setKeymapEntry(prompt, sessionRef.current) // so re-opening this finding restores it
    setSessionSummary(null)
    setCostEstimate(null)
    setExactTokens(null)
    send(prompt, { fresh: true })
  }

  const openReasoningTrace = () => {
    setTraceOpen(true)
    setTraceLoading(true)
    setTraceSelected(null)
    const sid = sessionRef.current
    reasoningApi
      .listInteractions(sid, { limit: 200 })
      .then((r: { interactions?: TraceItem[] }) => setTraceItems(r?.interactions || []))
      .catch(() => setTraceItems([]))
      .finally(() => setTraceLoading(false))
    reasoningApi
      .getSessionSummary(sid)
      .then((s: Partial<SessionSummary> | null) =>
        setSessionSummary(s ? sessionSummaryFrom(s) : null),
      )
      .catch(() => {})
  }

  const loadTraceInteraction = (interactionId: string) => {
    reasoningApi
      .getInteraction(sessionRef.current, interactionId)
      .then((d: TraceDetail) => setTraceSelected(d))
      .catch(() => {})
  }

  const deleteConversation = async (id: string) => {
    try {
      await conversationsApi.delete(id)
      reloadHistory()
    } catch {
      /* still drop it from the offline cache below */
    }
    setHistory((h) => {
      const next = h.filter((c) => c.id !== id)
      saveHistory(next)
      return next
    })
  }

  const archiveConversation = async (id: string, archived: boolean) => {
    try {
      await conversationsApi.update(id, { archived })
      reloadHistory()
    } catch {
      /* ignore — server unreachable */
    }
  }

  const commitRename = async (id: string) => {
    const title = renameDraft.trim()
    setRenamingId(null)
    if (!title) return
    try {
      await conversationsApi.update(id, { title })
      reloadHistory()
    } catch {
      /* ignore — server unreachable */
    }
  }

  // the marker is only set on success, so a failed import retries next mount
  const migratedRef = useRef(false)
  useEffect(() => {
    if (migratedRef.current) return
    migratedRef.current = true
    try {
      if (localStorage.getItem(IMPORT_MARKER_KEY)) return
      const local = loadHistory()
      if (local.length === 0) {
        localStorage.setItem(IMPORT_MARKER_KEY, '1')
        return
      }
      const payload: ImportConversationInput[] = local.map((c) => ({
        id: c.id,
        title: c.title,
        messages: (c.messages || [])
          .filter((m) => m.role !== 'error')
          .map((m) => ({ role: m.role === 'vigil' ? 'assistant' : 'user', content: m.text, thinking: null })),
      }))
      // preserve investigation dedup keys across the migration
      for (const c of local) if (c.key) setKeymapEntry(c.key, c.id)
      conversationsApi
        .importHistory(payload)
        .then(() => {
          try {
            localStorage.setItem(IMPORT_MARKER_KEY, '1')
          } catch {
            /* ignore */
          }
          reloadHistory()
        })
        .catch(() => {
          /* retry next mount */
        })
    } catch {
      /* empty */
    }
  }, [reloadHistory])

  const seedRef = useRef<string | null>(null)
  useEffect(() => {
    // reset when the parent clears the seed, so the same finding can be
    // investigated again
    if (!seed) {
      seedRef.current = null
      return
    }
    // guard against StrictMode's double-invoke firing the same seed twice
    if (open && seed !== seedRef.current && !loading) {
      seedRef.current = seed
      openInvestigation(seed)
      onSeedConsumed?.()
    }
    // send/loading intentionally omitted: we fire once per new seed
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, seed])
  const onKeyDown = (e: KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault()
      send()
    }
  }

  const clampWidth = (next: number) => Math.min(maxWidth, Math.max(minWidth, Math.round(next)))
  const onResizePointerDown = (event: ReactPointerEvent<HTMLDivElement>) => {
    if (event.button !== 0 || maxWidth <= minWidth) return
    const startWidth = clampWidth(width)
    resizeRef.current = {
      pointerId: event.pointerId,
      startX: event.clientX,
      startWidth,
      lastWidth: startWidth,
    }
    event.currentTarget.setPointerCapture?.(event.pointerId)
    setResizing(true)
    onResizeStateChange?.(true)
    event.preventDefault()
  }
  const onResizePointerMove = (event: ReactPointerEvent<HTMLDivElement>) => {
    const drag = resizeRef.current
    if (!drag || drag.pointerId !== event.pointerId) return
    const next = clampWidth(drag.startWidth + drag.startX - event.clientX)
    drag.lastWidth = next
    onWidthChange?.(next)
  }
  const finishResize = (event: ReactPointerEvent<HTMLDivElement>) => {
    const drag = resizeRef.current
    if (!drag || drag.pointerId !== event.pointerId) return
    if (event.currentTarget.hasPointerCapture?.(event.pointerId)) {
      event.currentTarget.releasePointerCapture?.(event.pointerId)
    }
    resizeRef.current = null
    setResizing(false)
    onResizeStateChange?.(false)
    onWidthCommit?.(drag.lastWidth)
  }
  const onResizeKeyDown = (event: KeyboardEvent<HTMLDivElement>) => {
    if (maxWidth <= minWidth) return
    const step = event.shiftKey ? 48 : 16
    let next: number | null = null
    if (event.key === 'ArrowLeft') next = width + step
    else if (event.key === 'ArrowRight') next = width - step
    else if (event.key === 'Home') next = minWidth
    else if (event.key === 'End') next = maxWidth
    if (next == null) return
    event.preventDefault()
    const clamped = clampWidth(next)
    onWidthChange?.(clamped)
    onWidthCommit?.(clamped)
  }

  return (
    <>
    <aside
      ref={panelRef}
      className={`chat${open ? ' open' : ''}${resizing ? ' resizing' : ''}`}
      role="dialog"
      aria-label="Vigil Assistant"
      aria-hidden={!open}
      onKeyDown={onPanelKeyDown}
    >
      <div
        className="chat-resize-handle"
        role="separator"
        aria-label="Resize Vigil Assistant"
        aria-orientation="vertical"
        aria-valuemin={Math.round(minWidth)}
        aria-valuemax={Math.round(maxWidth)}
        aria-valuenow={Math.round(width)}
        tabIndex={open && maxWidth > minWidth ? 0 : -1}
        onPointerDown={onResizePointerDown}
        onPointerMove={onResizePointerMove}
        onPointerUp={finishResize}
        onPointerCancel={finishResize}
        onKeyDown={onResizeKeyDown}
      />
      <div className="chat-head">
        <span className="ch-ico"><Icon name="brain" /></span>
        <h3 className="ch-title">Vigil Assistant</h3>
        <div className="hbtns">
          <button title="History" onClick={() => { setHistoryOpen(true); reloadHistory() }}><Icon name="clock" /></button>
          <button title="Reasoning trace" onClick={openReasoningTrace}><Icon name="reason" /></button>
          <button title="SOC Agents" onClick={() => setAgentsInfoOpen(true)}><Icon name="note" /></button>
          <button title="Chat settings" onClick={() => setSettingsOpen(true)}><Icon name="gear" /></button>
          <button title="Clear chat" onClick={reset} disabled={loading || messages.length === 0}><Icon name="trash" /></button>
          <button type="button" title="Close assistant" aria-label="Close Vigil Assistant" onClick={onClose}><Icon name="close" /></button>
        </div>
      </div>

      <div className="chat-body" ref={bodyRef}>
        {messages.length === 0 && !loading && (
          <div className="chat-empty">Ask Vigil to investigate a finding, correlate activity, or summarize a case.</div>
        )}
        {messages.map((m, i) =>
          m.role === 'user' ? (
            <div className="msg user" key={i}><div className="body">{m.text}</div></div>
          ) : m.role === 'error' ? (
            <div className="msg vigil err" key={i}><div className="body">{m.text}</div></div>
          ) : (
            <VigilMessage key={i} text={m.text} ms={m.ms} />
          )
        )}
        {loading && (
          <div className="msg vigil">
            {/* always-on processing indicator so the user knows Vigil is still
                working — the phase label tracks reasoning → responding */}
            <div className="vigil-status" aria-live="polite">
              <span className="vs-dots" aria-hidden="true"><i /><i /><i /></span>
              <span className="vs-label">
                {isProcessingTools ? 'Vigil is running tools' : streamText ? 'Vigil is responding' : 'Vigil is working on it'}
                …
              </span>
            </div>
            {streamText && <div className="body"><Markdown>{streamText}</Markdown></div>}
          </div>
        )}
      </div>

      <div className="chat-foot">
        <div className="chat-meta">
          <div className="cm-line">
            <span className={`cm-ctx ${ctxState}`} title="Estimated context usage for the next request">
              {estimatedTokens.toLocaleString()} / {CONTEXT_WINDOW / 1000}k tokens
            </span>
            {costEstimate && (
              <Cost className="cm-cost" title={costTitle} approx usd={costEstimate.low_usd} high={costEstimate.high_usd} source={costEstimate.pricing_source} digits={4} />
            )}
          </div>
          <div className="cm-bar"><span className={`cm-bar-fill ${ctxState}`} style={{ width: `${ctxPct}%` }} /></div>
        </div>
        <div className="chat-input">
          <textarea
            ref={taRef}
            rows={1}
            placeholder="Ask Vigil, / for commands, @ for context"
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={onKeyDown}
          />
          <div className="ci-row">
            <div className="model-wrap" ref={menuRef}>
              <button className="model-sel" onClick={() => setMenuOpen((o) => !o)}>
                <span className="m-ico"><Icon name="infinity" /></span>
                {agentName} <span className="dd"><Icon name="chevD" size={12} /></span>
              </button>
              {menuOpen && (
                <div className="agent-menu">
                  <button className={agentId === '' ? 'sel' : ''} onClick={() => { setAgentId(''); setMenuOpen(false) }}>
                    Default agent<span className="am-spec">No specific agent</span>
                  </button>
                  {agents.map((a) => (
                    <button key={a.id} className={a.id === agentId ? 'sel' : ''} onClick={() => { setAgentId(a.id); setMenuOpen(false) }}>
                      <span className="am-name">
                        {a.icon && <span className="am-ico" style={{ color: a.color }}>{a.icon}</span>}
                        {a.name}
                      </span>
                      {a.specialization && <span className="am-spec">{a.specialization}</span>}
                      {a.description && <span className="am-desc">{a.description}</span>}
                    </button>
                  ))}
                </div>
              )}
            </div>
            <div className="ci-grow" />
            {loading ? (
              <button className="ci-send busy" title="Stop" onClick={stop}><Icon name="x2" size={15} /></button>
            ) : (
              <button className="ci-send" title="Send" onClick={() => send()} disabled={!draft.trim()}><Icon name="send" /></button>
            )}
          </div>
        </div>
      </div>
    </aside>

    {/* Conversation history — server-backed (cross-device); falls back to the
        localStorage cache when the server can't be reached. */}
    <Popup open={historyOpen} onClose={() => setHistoryOpen(false)} title="Conversation history" width={460}>
      {(() => {
        const offline = histPhase === 'error'
        const rows: HistRow[] = offline
          ? history.map((c) => ({
              id: c.id,
              title: c.title || 'Untitled conversation',
              count: c.messages?.length || 0,
              ts: c.ts || null,
            }))
          : serverConvos.map((c) => ({
              id: c.id,
              title: c.title || 'Untitled conversation',
              count: c.message_count,
              ts: c.last_message_at
                ? Date.parse(c.last_message_at)
                : c.updated_at
                  ? Date.parse(c.updated_at)
                  : null,
              archived: c.archived,
            }))
        return (
          <>
            <div className="chist-toolbar">
              {offline && <span className="muted">Offline — showing cached conversations.</span>}
              <label className="chist-archtoggle">
                <input
                  type="checkbox"
                  checked={showArchived}
                  onChange={(e) => setShowArchived(e.target.checked)}
                  disabled={offline}
                />
                Show archived
              </label>
            </div>
            {histPhase === 'loading' ? (
              <div className="muted">Loading…</div>
            ) : rows.length === 0 ? (
              <div className="muted">
                No past conversations yet. Your chats are saved automatically so you can
                reopen them on any device.
              </div>
            ) : (
              <div className="chat-history">
                {rows.map((c) => (
                  <div
                    key={c.id}
                    className={`chist-row${c.id === sessionRef.current ? ' current' : ''}${c.archived ? ' archived' : ''}`}
                  >
                    {renamingId === c.id ? (
                      <input
                        className="chist-rename"
                        autoFocus
                        value={renameDraft}
                        onChange={(e) => setRenameDraft(e.target.value)}
                        onKeyDown={(e) => {
                          if (e.key === 'Enter') {
                            e.preventDefault()
                            commitRename(c.id)
                          } else if (e.key === 'Escape') {
                            setRenamingId(null)
                          }
                        }}
                        onBlur={() => commitRename(c.id)}
                      />
                    ) : (
                      <button className="chist-main" onClick={() => openConversation(c.id)}>
                        <span className="chist-title">{c.title}</span>
                        <span className="chist-meta">
                          {c.count} message{c.count === 1 ? '' : 's'}
                          {c.ts != null && histTime(c.ts) ? ` · ${histTime(c.ts)}` : ''}
                        </span>
                      </button>
                    )}
                    <div className="chist-actions">
                      <button
                        className="chist-act"
                        title="Rename"
                        disabled={offline}
                        onClick={() => {
                          setRenamingId(c.id)
                          setRenameDraft(c.title)
                        }}
                      >
                        <Icon name="edit" size={14} />
                      </button>
                      <button
                        className="chist-act"
                        title={c.archived ? 'Unarchive' : 'Archive'}
                        disabled={offline}
                        onClick={() => archiveConversation(c.id, !c.archived)}
                      >
                        <Icon name="folder" size={14} />
                      </button>
                      <button
                        className="chist-act chist-del"
                        title="Delete"
                        onClick={() => deleteConversation(c.id)}
                      >
                        <Icon name="trash" size={14} />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </>
        )
      })()}
    </Popup>

    {/* Chat settings — Status / Model settings / Advanced (mirrors the classic drawer) */}
    <Popup open={settingsOpen} onClose={() => setSettingsOpen(false)} title="Chat settings" width={440}>
      <div className="chat-settings">
        {/* Status */}
        <section className="cs-sec">
          <div className="cs-head">Status</div>
          <div className="cs-stat-row">
            <span className="cs-name">MCP Tools</span>
            {mcpStatus ? (
              <span className={`cs-chip ${mcpStatus.available > 0 ? 'ok' : 'danger'}`}>
                {mcpStatus.available}/{mcpStatus.total}
              </span>
            ) : (
              <span className="muted">checking…</span>
            )}
          </div>
          <div className="cs-ctx">
            <span className={`cs-ctx-label ${ctxState}`}>
              Context {exactTokens != null ? '' : '~'}{estimatedTokens.toLocaleString()} / {CONTEXT_WINDOW.toLocaleString()} tokens
            </span>
            <div className="cs-bar"><span className={`cs-bar-fill ${ctxState}`} style={{ width: `${ctxPct}%` }} /></div>
            <span className="cs-ctx-sub">Output max {maxTokens.toLocaleString()} tokens</span>
          </div>
          {costEstimate && (
            <div className="cs-stat-row" title={costTitle}>
              <span className="cs-name">Est. cost</span>
              <Cost className="cs-cost-val" usd={costEstimate.low_usd} high={costEstimate.high_usd} source={costEstimate.pricing_source} digits={4} />
            </div>
          )}
        </section>

        {/* Model settings */}
        <section className="cs-sec">
          <div className="cs-head">Model settings</div>
          <div className="cs-field">
            <span className="cs-name">Model</span>
            <Select
              value={model}
              onSelect={(m) => { userPickedModelRef.current = true; setModel(m) }}
              options={(models.length ? models : MODEL_FALLBACK).map((m) => ({ value: m.id, label: m.name }))}
            />
          </div>
          <div className="cs-field">
            <span className="cs-name">Max tokens</span>
            <input
              className="cs-input"
              type="number"
              min={256}
              max={64000}
              value={maxTokens}
              onChange={(e) => setMaxTokens(parseInt(e.target.value, 10) || 4096)}
            />
          </div>
        </section>

        {/* Advanced */}
        <section className="cs-sec">
          <div className="cs-head">Advanced</div>
          <div className="cs-field">
            <span className="cs-name">System prompt <span className="cs-opt">(optional)</span></span>
            <textarea
              className="cs-input cs-area"
              rows={3}
              value={systemPrompt}
              placeholder="Override default system prompt…"
              onChange={(e) => setSystemPrompt(e.target.value)}
            />
            <span className="cs-help">Leave empty to use the default prompt. Settings are saved automatically.</span>
          </div>
        </section>
      </div>
    </Popup>

    {/* SOC Agents reference — rendered outside the transformed .chat aside so
        the fixed overlay positions against the viewport */}
    <Popup open={agentsInfoOpen} onClose={() => setAgentsInfoOpen(false)} title="SOC Agents" width={460}>
      {agents.length === 0 ? (
        <div className="muted">No agents available.</div>
      ) : (
        <div className="agent-cards">
          {agents.map((a) => (
            <div key={a.id} className="agent-card" style={{ borderLeftColor: a.color || 'var(--accent)' }}>
              <div className="ac-head">
                {a.icon && <span className="ac-ico" style={{ color: a.color }}>{a.icon}</span>}
                <span className="ac-name">{a.name}</span>
                {a.specialization && <span className="ac-spec">{a.specialization}</span>}
              </div>
              {a.description && <p className="ac-desc">{a.description}</p>}
            </div>
          ))}
        </div>
      )}
    </Popup>

    {/* Reasoning trace — per-interaction chain-of-thought for this session */}
    <Popup open={traceOpen} onClose={() => setTraceOpen(false)} title="Reasoning trace" width={760}>
      {sessionSummary && (
        <div className="trace-sum">
          {sessionSummary.total_interactions} call{sessionSummary.total_interactions === 1 ? '' : 's'}
          {' · '}<Cost usd={sessionSummary.total_cost_usd} digits={4} />
          {sessionSummary.unpriced_calls > 0 && (
            <>{' · '}{sessionSummary.unpriced_calls.toLocaleString()} unpriced</>
          )}
          {' · '}{(sessionSummary.total_input_tokens + sessionSummary.total_output_tokens).toLocaleString()} tokens
        </div>
      )}
      <div className="trace">
        <div className="trace-list">
          {traceLoading ? (
            <div className="muted">Loading…</div>
          ) : traceItems.length === 0 ? (
            <div className="muted">No reasoning recorded for this conversation yet.</div>
          ) : (
            traceItems.map((it) => (
              <button
                key={it.interaction_id}
                className={`trace-row${traceSelected?.interaction_id === it.interaction_id ? ' sel' : ''}`}
                onClick={() => loadTraceInteraction(it.interaction_id)}
              >
                <span className="trace-row-top">
                  <span>{traceTime(it.created_at)}</span>
                  {it.has_thinking && <span className="trace-chip" title="Has thinking">💭</span>}
                  {it.has_tools && <span className="trace-chip" title="Used tools">🔧</span>}
                  <span className="trace-row-agent">{it.agent_id || 'chat'}</span>
                </span>
                <span className="trace-row-meta">
                  {(it.input_tokens ?? 0).toLocaleString()} in · {(it.output_tokens ?? 0).toLocaleString()} out · <Cost usd={it.cost_usd} digits={4} />
                </span>
              </button>
            ))
          )}
        </div>
        <div className="trace-detail">
          {!traceSelected ? (
            <div className="muted">{traceItems.length ? 'Select an interaction to inspect its reasoning.' : ''}</div>
          ) : (
            <>
              <div className="trace-meta">
                <span>{traceSelected.model || '—'}</span>
                {traceSelected.stop_reason && <span>· {traceSelected.stop_reason}</span>}
                {typeof traceSelected.duration_ms === 'number' && <span>· {(traceSelected.duration_ms / 1000).toFixed(1)}s</span>}
                <span>· <Cost usd={traceSelected.cost_usd} digits={4} /></span>
              </div>
              {traceSelected.thinking_content && (
                <div className="trace-block thinking">
                  <div className="trace-block-h">💭 Thinking</div>
                  <div className="trace-block-b">{traceSelected.thinking_content}</div>
                </div>
              )}
              {traceSelected.response_content && (
                <div className="trace-block">
                  <div className="trace-block-h">Response</div>
                  <div className="trace-block-b"><Markdown>{traceSelected.response_content}</Markdown></div>
                </div>
              )}
              {traceSelected.tool_calls?.map((tc, i) => (
                <div key={`c${i}`} className="trace-block tool">
                  <div className="trace-block-h">🔧 {tc.name || 'tool'}</div>
                  <div className="trace-block-b mono">{safeJson(tc.input)}</div>
                </div>
              ))}
              {traceSelected.tool_results?.map((tr, i) => (
                <div key={`r${i}`} className={`trace-block ${tr.is_error ? 'err' : 'ok'}`}>
                  <div className="trace-block-h">{tr.is_error ? 'Tool error' : 'Tool result'}</div>
                  <div className="trace-block-b mono">{typeof tr.content === 'string' ? tr.content : safeJson(tr.content)}</div>
                </div>
              ))}
            </>
          )}
        </div>
      </div>
    </Popup>
    </>
  )
}
